<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>SwapConnect</title>
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/shop-homepage.css" rel="stylesheet">
    <!-- Item Bootstrap -->
    <link href="startbootstrap-shop-item-gh-pages/css/shop-item.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>

<body>
<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.php">SwapConnect</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Accueil

                    </a>
                </li>
                <?php
                if (!isset($_SESSION['email'])) {
                    ?>
                    <li class="nav-item">
                        <a class="nav-link" href="loginView.php">Se connecter</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="AdhererView.php">S'inscrire</a>
                    </li>
                    <li class="nav-item">
                        <form class="form-inline my-2 my-lg-0" method="GET" action="Recherche.php">
                            <input class="form-control mr-sm-2" type="text" placeholder="Que recherchez-vous ?" name="recherche" id="recherche">

                        </form>
                    </li>
                    <?php
                }
                ?>
                <?php
                if (isset($_SESSION['email'])) {
                    ?>
                    <li class="nav-item">
                        <a class="nav-link" href="produitView.php">Ajouter un Produit</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Profile.php">Profil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#"><img src="./image/imgJeton.png" alt="Token" class="img-fluid" style="max-width: 20px;min-width: 15px;max-height: 20px; min-height: 15px;"/> Acheter des SwapCoins</a>
                    </li>
                    <li class="nav-item">
                        <form class="form-inline my-2 my-lg-0" method="GET" action="Recherche.php">
                            <input class="form-control mr-sm-2" type="text" placeholder="Que recherchez-vous ?" name="recherche" id="recherche">

                        </form>
                    </li>
                    <li class="nav-item">
                    <a href="logoutController.php"><button class="btn btn-danger" style="margin-left: 4px;">Se deconnecter</button></a>
                    </li>
                    <?php
                }
                ?>

            </ul>
        </div>
    </div>
</nav>
