<?php
/**
 * Created by PhpStorm.
 * User: hadri
 * Date: 31/10/2018
 * Time: 18:57
 */
include("Header.php");
include("Model.php");
date_default_timezone_set("Europe/Paris");
$id_produit = htmlspecialchars($_GET["id"]);
$id_acheteur = $_SESSION ['id_user'];
?>
<html>
<body>

<!-- Page Content -->
<div class="container">
    <div class="row">
        <div class="col-lg-15">
        </div>

        <div class="col-lg-2">
        </div>
        <!-- /.col-lg-3 -->
        <?php
        achatController($id_produit, $id_acheteur);
        ?>
        <div class="col-lg-2">
        </div>
    </div>

</div>
<!-- /.container -->

<!-- Footer -->
<footer class="py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright Hadrien HURET et Yohan Angelini &copy; SwapConnect 2018</p>
    </div>
    <!-- /.container -->
</footer>

<!-- Bootstrap core JavaScript -->
<script src="startbootstrap-shop-item-gh-pages/vendor/jquery/jquery.min.js"></script>
<script src="startbootstrap-shop-item-gh-pages/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>