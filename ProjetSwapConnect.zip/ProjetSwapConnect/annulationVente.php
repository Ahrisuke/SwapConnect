<?php
/**
 * Created by PhpStorm.
 * User: hadri
 * Date: 02/11/2018
 * Time: 17:17
 */
include("Header.php");
include("Model.php");
$id_produit = htmlspecialchars($_GET["id"]);
remiseEnVente($id_produit);
?>
<div style="text-align: center;">
        <br/><br/><br/><br/>
        <b>Vous avez refusé une offre pour votre produit.<br/>
        Votre produit vient d'être remis en vente !<br/><br/>
        Vous allez être redirigé vers votre profil dans 5 secondes.</b>
    </div>
<?php
header( "refresh:5;url=Profile.php" );