<?php

function getDataBase()
{
    $host = "localhost";
    $dbName = "swapconnect";
    $login = "root";
    $password = "";

    try {
        $bdd = new PDO('mysql:host=' . $host . ';dbname=' . $dbName . ';charset=utf8', $login, $password, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
    } catch (Exception $e) {
        $bdd = null;
        die('Erreur : ' . $e->getMessage());
    }

    return $bdd;
}

function authenticateUser($email, $mdp)
{

    $user = null;

    $bdd = getDataBase();
    if ($bdd == null) {
        $bdd = getDataBase();
    }

    $connect = false;
    if ($bdd) {
        try {
            $stmt = $bdd->prepare("SELECT * FROM utilisateurs WHERE email=:pEmail AND mdp=:pMdp");
            $stmt->bindParam(':pEmail', $email);
            $stmt->bindParam(':pMdp', $mdp);
            if ($stmt->execute()) {
                $user = $stmt->fetch(PDO::FETCH_OBJ);
                if ($user && $mdp == $user->mdp) {
                    $connect = true;
                }
            }

        } catch (Exception $e) {
            $connect = false;
        }
    }
    if ($connect) {

        return $user;
    }
    return null;
}

function ajUtilisateur($nom, $prenom, $adresse1, $adresse2, $cp, $ville, $email, $pays, $mdp)
{
    $newId = null;
    $bdd = getDataBase();
    if ($bdd == null) {
        $bdd = getDataBase();
    }
    // La bd est-elle valide ?
    if (isset($bdd)) {
 
        try {
            // Insertion dans la bd
            $stmt = $bdd->prepare("INSERT INTO utilisateurs (nom, prenom, adresse1, adresse2, cp, ville, email, pays, mdp)
                                            VALUES( :pNom, :pPrenom, :pAdresse1, :pAdresse2, :pCp, :pVille, :pEmail, :pPays, :pMdp)");
            $stmt->bindParam(':pNom', $nom);
            $stmt->bindParam(':pPrenom', $prenom);
            $stmt->bindParam(':pAdresse1', $adresse1);
            $stmt->bindParam(':pAdresse2', $adresse2);
            $stmt->bindParam(':pCp', $cp);
            $stmt->bindParam(':pVille', $ville);
            $stmt->bindParam(':pEmail', $email);
            $stmt->bindParam(':pPays', $pays);
            $stmt->bindParam(':pMdp', $mdp);
            if ($stmt->execute()) {
                // On récupère l'ID de la commandes
                $newId = 1;
                ?>
                <html>
                <div class="container">
                    <div class="row">
                        <h1 class="my-4 text-uppercase">Votre compte <b style="color: green;"><u>a bien été créé</u></b>.
                            <br/> Vous allez être redirigé dans 3 secondes...</h1>
                    </div>
                </div>
                </html>
                <?php
                header("refresh:3;url=index.php");
            }
        } catch (Exception $e) {
            ?>
            <html>
            <!-- Page Content -->
            <div class="container">
                <div class="row">
                    <h1 class="my-4 text-uppercase">L'email que vous avez entré <b style="color: red;"><u>possède déja un compte</u></b>.
                        <br/> Vous allez être redirigé dans 3 secondes...</h1>
                </div>
            </div>
            </html>
            <?php
            $newId = 0;
            header("refresh:3;url=AdhererView.php");
        }
    }
    return $newId;
}

function ajUtilisateur2($nom, $prenom, $adresse1, $cp, $ville, $email, $pays, $mdp)
{
    $newId = null;
    $bdd = getDataBase();
    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // La bd est-elle valide ?
    if (isset($bdd)) {

        try {
            // Insertion dans la bd
            $stmt = $bdd->prepare("INSERT INTO utilisateurs (nom, prenom, adresse1, cp, ville, email, pays, mdp)
                                            VALUES( :pNom, :pPrenom, :pAdresse1, :pCp, :pVille, :pEmail, :pPays, :pMdp)");
            $stmt->bindParam(':pNom', $nom);
            $stmt->bindParam(':pPrenom', $prenom);
            $stmt->bindParam(':pAdresse1', $adresse1);
            $stmt->bindParam(':pCp', $cp);
            $stmt->bindParam(':pVille', $ville);
            $stmt->bindParam(':pEmail', $email);
            $stmt->bindParam(':pPays', $pays);
            $stmt->bindParam(':pMdp', $mdp);
            if ($stmt->execute()) {
                // On récupère l'ID de la commandes
                $newId = 1;
                ?>
                <html>
                <!-- Page Content -->
                <div class="container">
                    <div class="row">
                        <h1 class="my-4 text-uppercase">Votre compte <b style="color: green;"><u>a bien été créé</u></b>.
                            <br/> Vous allez être redirigé dans 3 secondes...</h1>
                    </div>
                </div>
                </html>
                <?php
                header("refresh:3;url=index.php");
            }
        } catch (Exception $e) {
            ?>
            <html>
            <!-- Page Content -->
            <div class="container">
                <div class="row">
                    <h1 class="my-4 text-uppercase">L'email que vous avez entré <b style="color: red;"><u>possède déja un compte</u></b>.
                        <br/> Vous allez être redirigé dans 3 secondes...</h1>
                </div>
            </div>
            </html>
            <?php
            $newId = 0;
            header("refresh:3;url=AdhererView.php");
        }
    }
    return $newId;
}

function ajouterProduit ($nom_prod, $prix_prod, $desc_prod, $etat_prod, $target_file, $cat, $id)
{
    $bdd = getDataBase();
    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // BDD valide ?
    if (isset($bdd)) {

        try {
            // Insertion dans la BDD
            $stmt = $bdd->prepare("INSERT INTO produits (nom, prix_jeton, description, etat, photo, libelle, id_utilisateur)
                                            VALUES( :pnomproduit, :pprixjeton, :pdescription, :petat, :pphoto, :pcat, :pid_user)");
            $stmt->bindParam(':pnomproduit', $nom_prod);
            $stmt->bindParam(':pprixjeton', $prix_prod);
            $stmt->bindParam(':pdescription', $desc_prod);
            $stmt->bindParam(':petat', $etat_prod);
            $stmt->bindParam(':pphoto', $target_file);
            $stmt->bindParam(':pcat', $cat);
            $stmt->bindParam(':pid_user', $id);
            $stmt->execute();
        } catch (Exception $e) {
            die('Erreur : ' . $e->getMessage());
        }
    }
}

function returnUtilisateur($id)
{
    {
        $bdd = null;

        if ($bdd == null) {
            $bdd = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd) {
            // Obtention de la liste des pays
            $resultat = $bdd->query("SELECT * FROM utilisateurs WHERE id_utilisateur = $id");
            if ($resultat) {
                $utilisateur = $resultat->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat->closeCursor();
            }
        }
        return $utilisateur;
    }
}

function returnProduit()
{
    {
        $bdd = null;

        if ($bdd == null) {
            $bdd = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd) {
            // Obtention de la liste des pays
            $resultat = $bdd->query("SELECT * FROM produits");
            if ($resultat) {
                $productList = $resultat->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat->closeCursor();
            }
        }
        return $productList;
    }
}

function countReturnProduit ()
{
    {
        $bdd = null;

        if ($bdd == null) {
            $bdd = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd) {
            // Obtention de la liste des pays
            $resultat = $bdd->query("SELECT COUNT(*) as count FROM produits");
            if ($resultat) {
                $countProductList = $resultat->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat->closeCursor();
            }
        }
        return $countProductList;
    }

}

function afficheProduitIndex($listProd)
{
    $count = (int)countReturnProduit()[0]->count;
    for($i=0;$i<$count;$i++)
    {
        if (($listProd[$i]->dispo) == 0) { ?>
        <html>
        <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100">
                    <a href="Item.php?id=<?=$listProd[$i]->id_produit;?>">
                        <img class="card-img-top" src="<?=$listProd[$i]->photo;?>" alt="" style="width: 200px;height: 150px;"/>
                    </a>
                    <div class="card-body">
                        <h4 class="card-title">
                            <a href="Item.php?id=<?=$listProd[$i]->id_produit;?>"><?=$listProd[$i]->nom;?></a>
                        </h4>
                        <h5><?=$listProd[$i]->prix_jeton;?> SwapCoin</h5>
                        <p class="card-text"><?=substr($listProd[$i]->description, 0, 100);?> ...</p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                    </div>
                </div>
            </div>
        </html>
    <?php
    }
    }
}

// ---------------------------------------------------------------
// PARTIE AFFICHAGE SPORT
// ---------------------------------------------------------------
function returnProduitSport()
{
    {
        $bdd2 = null;
        $sport = "Sport";

        if ($bdd2 == null) {
            $bdd2 = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd2) {
            // Obtention de la liste des pays
            $resultat2 = $bdd2->query("SELECT * FROM produits WHERE libelle='$sport'");
            if ($resultat2) {
                $productListSport = $resultat2->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat2->closeCursor();
            }
        }
        return $productListSport;
    }
}

function countReturnProduitSport()
    {
        $bdd = null;
        $sport = "Sport";

        if ($bdd == null) {
            $bdd = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd) {
            // Obtention de la liste des pays
            $smtp2 = $bdd->query("SELECT COUNT(*) as count FROM produits WHERE libelle = '$sport'");
            if ($smtp2) {
                $countProductListSport = $smtp2->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $smtp2->closeCursor();
            }
        }
        return $countProductListSport;
    }

    function afficheProduitSport($listProdSport)
    {
        $countSport = (int)countReturnProduitSport()[0]->count;
        for ($i = 0; $i < $countSport; $i++) {
            if (($listProdSport[$i]->dispo) == 0) { ?>
                <html>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100">
                        <a href="Item.php?id=<?= $listProdSport[$i]->id_produit; ?>">
                            <img class="img-responsive" src="<?= $listProdSport[$i]->photo; ?>" alt=""
                                 style="height: 150px; max-width: 250px;"/>
                        </a>
                        <div class="card-body">
                            <h4 class="card-title">
                                <a href="Item.php?id=<?= $listProdSport[$i]->id_produit; ?>"><?= $listProdSport[$i]->nom; ?></a>
                            </h4>
                            <h5><?= $listProdSport[$i]->prix_jeton; ?> SwapCoin</h5>
                            <p class="card-text"><?= substr($listProdSport[$i]->description, 0, 200); ?> ...</p>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                        </div>
                    </div>
                </div>
                </html>
            <?php }
        }
    }

// ---------------------------------------------------------------
// PARTIE AFFICHAGE MOBILITE
// ---------------------------------------------------------------
function returnProduitMobilite()
{
    {
        $bdd2 = null;
        $mobilite = "Mobilite";

        if ($bdd2 == null) {
            $bdd2 = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd2) {
            // Obtention de la liste des pays
            $resultat2 = $bdd2->query("SELECT * FROM produits WHERE libelle='$mobilite'");
            if ($resultat2) {
                $productListMobilite= $resultat2->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat2->closeCursor();
            }
        }
        return $productListMobilite;
    }
}

function countReturnProduitMobilite()
{
    $bdd = null;
    $mobilite = "Mobilite";

    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // La bd est-elle valide ?
    if ($bdd) {
        // Obtention de la liste des pays
        $smtp2 = $bdd->query("SELECT COUNT(*) as count FROM produits WHERE libelle = '$mobilite'");
        if ($smtp2) {
            $countProductListMobilite = $smtp2->fetchAll(PDO::FETCH_OBJ);
            // Fermeture de la ressource
            $smtp2->closeCursor();
        }
    }
    return $countProductListMobilite;
}

function afficheProduitMobilite($listProdMobilite)
{
    $countMobilite = (int)countReturnProduitMobilite()[0]->count;
    for ($i = 0; $i < $countMobilite; $i++) {
        if (($listProdMobilite[$i]->dispo) == 0) { ?>
            <html>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100">
                    <a href="Item.php?id=<?= $listProdMobilite[$i]->id_produit; ?>">
                        <img class="img-responsive" src="<?= $listProdMobilite[$i]->photo; ?>" alt=""
                             style="height: 150px;"/>
                    </a>
                    <div class="card-body">
                        <h4 class="card-title">
                            <a href="Item.php?id=<?= $listProdMobilite[$i]->id_produit; ?>"><?= $listProdMobilite[$i]->nom; ?></a>
                        </h4>
                        <h5><?= $listProdMobilite[$i]->prix_jeton; ?> SwapCoin</h5>
                        <p class="card-text"><?= substr($listProdMobilite[$i]->description, 0, 200); ?> ...</p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                    </div>
                </div>
            </div>
            </html>
        <?php }
    }
}

// ---------------------------------------------------------------
// PARTIE AFFICHAGE DOMOTIQUE
// ---------------------------------------------------------------
function returnProduitDomotique()
{
    {
        $bdd2 = null;
        $domotique = "Domotique";

        if ($bdd2 == null) {
            $bdd2 = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd2) {
            // Obtention de la liste des pays
            $resultat2 = $bdd2->query("SELECT * FROM produits WHERE libelle='$domotique'");
            if ($resultat2) {
                $productListDomotique= $resultat2->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat2->closeCursor();
            }
        }
        return $productListDomotique;
    }
}

function countReturnProduitDomotique()
{
    $bdd = null;
    $domotique = "Domotique";

    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // La bd est-elle valide ?
    if ($bdd) {
        // Obtention de la liste des pays
        $smtp2 = $bdd->query("SELECT COUNT(*) as count FROM produits WHERE libelle = '$domotique'");
        if ($smtp2) {
            $countProductListDomotique = $smtp2->fetchAll(PDO::FETCH_OBJ);
            // Fermeture de la ressource
            $smtp2->closeCursor();
        }
    }
    return $countProductListDomotique;
}

function afficheProduitDomotique($listProdDomotique)
{
    $countDomotique = (int)countReturnProduitDomotique()[0]->count;
    for ($i = 0; $i < $countDomotique; $i++) {
        if (($listProdDomotique[$i]->dispo) == 0) { ?>
            <html>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100">
                    <a href="Item.php?id=<?= $listProdDomotique[$i]->id_produit; ?>">
                        <img class="img-responsive" src="<?= $listProdDomotique[$i]->photo; ?>" alt=""
                             style="height: 150px;"/>
                    </a>
                    <div class="card-body">
                        <h4 class="card-title">
                            <a href="Item.php?id=<?= $listProdDomotique[$i]->id_produit; ?>"><?= $listProdDomotique[$i]->nom; ?></a>
                        </h4>
                        <h5><?= $listProdDomotique[$i]->prix_jeton; ?> SwapCoin</h5>
                        <p class="card-text"><?= substr($listProdDomotique[$i]->description, 0, 200); ?> ...</p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                    </div>
                </div>
            </div>
            </html>
        <?php }
    }
}

// ---------------------------------------------------------------
// PARTIE AFFICHAGE ACCESSOIRE
// ---------------------------------------------------------------
function returnProduitAccessoire()
{
    {
        $bdd2 = null;
        $accessoire = "Accessoire";

        if ($bdd2 == null) {
            $bdd2 = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd2) {
            // Obtention de la liste des pays
            $resultat2 = $bdd2->query("SELECT * FROM produits WHERE libelle='$accessoire'");
            if ($resultat2) {
                $productListAccessoire= $resultat2->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat2->closeCursor();
            }
        }
        return $productListAccessoire;
    }
}

function countReturnProduitAccessoire()
{
    $bdd = null;
    $accessoire = "Accessoire";

    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // La bd est-elle valide ?
    if ($bdd) {
        // Obtention de la liste des pays
        $smtp2 = $bdd->query("SELECT COUNT(*) as count FROM produits WHERE libelle = '$accessoire'");
        if ($smtp2) {
            $countProductListAccessoire = $smtp2->fetchAll(PDO::FETCH_OBJ);
            // Fermeture de la ressource
            $smtp2->closeCursor();
        }
    }
    return $countProductListAccessoire;
}

function afficheProduitAccessoire($listProdAccessoire)
{
    $countAccessoire = (int)countReturnProduitAccessoire()[0]->count;
    for ($i = 0; $i < $countAccessoire; $i++) {
        if (($listProdAccessoire[$i]->dispo) == 0) { ?>
            <html>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100">
                    <a href="Item.php?id=<?= $listProdAccessoire[$i]->id_produit; ?>">
                        <img class="img-responsive" src="<?= $listProdAccessoire[$i]->photo; ?>" alt=""
                             style="height: 150px;"/>
                    </a>
                    <div class="card-body">
                        <h4 class="card-title">
                            <a href="Item.php?id=<?= $listProdAccessoire[$i]->id_produit; ?>"><?= $listProdAccessoire[$i]->nom; ?></a>
                        </h4>
                        <h5><?= $listProdAccessoire[$i]->prix_jeton; ?> SwapCoin</h5>
                        <p class="card-text"><?= substr($listProdAccessoire[$i]->description, 0, 200); ?> ...</p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                    </div>
                </div>
            </div>
            </html>
        <?php }
    }
}


// ---------------------------------------------------------------
// PARTIE AFFICHAGE MULTIMEDIA
// ---------------------------------------------------------------
function returnProduitMultimedia()
{
    {
        $bdd2 = null;
        $multimedia = "Multimedia";

        if ($bdd2 == null) {
            $bdd2 = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd2) {
            // Obtention de la liste des pays
            $resultat2 = $bdd2->query("SELECT * FROM produits WHERE libelle='$multimedia'");
            if ($resultat2) {
                $productListMultimedia= $resultat2->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat2->closeCursor();
            }
        }
        return $productListMultimedia;
    }
}

function countReturnProduitMultimedia()
{
    $bdd = null;
    $multimedia = "Multimedia";

    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // La bd est-elle valide ?
    if ($bdd) {
        // Obtention de la liste des pays
        $smtp2 = $bdd->query("SELECT COUNT(*) as count FROM produits WHERE libelle = '$multimedia'");
        if ($smtp2) {
            $countProductListMultimedia = $smtp2->fetchAll(PDO::FETCH_OBJ);
            // Fermeture de la ressource
            $smtp2->closeCursor();
        }
    }
    return $countProductListMultimedia;
}

function afficheProduitMultimedia($listProdMultimedia)
{
    $countMultimedia = (int)countReturnProduitMultimedia()[0]->count;
    for($i=0;$i<$countMultimedia;$i++) {
        if (($listProdMultimedia[$i]->dispo) == 0) { ?>
            <html>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100">
                    <a href="Item.php?id=<?= $listProdMultimedia[$i]->id_produit; ?>">
                        <img class="img-responsive" src="<?= $listProdMultimedia[$i]->photo; ?>" alt=""
                             style="height: 150px;"/>
                    </a>
                    <div class="card-body">
                        <h4 class="card-title">
                            <a href="Item.php?id=<?= $listProdMultimedia[$i]->id_produit; ?>"><?= $listProdMultimedia[$i]->nom; ?></a>
                        </h4>
                        <h5><?= $listProdMultimedia[$i]->prix_jeton; ?> SwapCoin</h5>
                        <p class="card-text"><?= substr($listProdMultimedia[$i]->description, 0, 200); ?> ...</p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                    </div>
                </div>
            </div>
            </html>
        <?php }
    }
}

// ---------------------------------------------------------------
// PARTIE AFFICHAGE LOISIRS
// ---------------------------------------------------------------
function returnProduitLoisirs()
{
    {
        $bdd2 = null;
        $loisirs = "Loisirs";

        if ($bdd2 == null) {
            $bdd2 = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd2) {
            // Obtention de la liste des pays
            $resultat2 = $bdd2->query("SELECT * FROM produits WHERE libelle='$loisirs'");
            if ($resultat2) {
                $productListLoisirs= $resultat2->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat2->closeCursor();
            }
        }
        return $productListLoisirs;
    }
}

function countReturnProduitLoisirs()
{
    $bdd = null;
    $loisirs = "Loisirs";

    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // La bd est-elle valide ?
    if ($bdd) {
        // Obtention de la liste des pays
        $smtp2 = $bdd->query("SELECT COUNT(*) as count FROM produits WHERE libelle = '$loisirs'");
        if ($smtp2) {
            $countProductListLoisirs = $smtp2->fetchAll(PDO::FETCH_OBJ);
            // Fermeture de la ressource
            $smtp2->closeCursor();
        }
    }
    return $countProductListLoisirs;
}

function afficheProduitLoisirs($listProdLoisirs)
{
    $countLoisirs = (int)countReturnProduitLoisirs()[0]->count;
    for($i=0;$i<$countLoisirs;$i++) {
        if (($listProdLoisirs[$i]->dispo) == 0) { ?>
            <html>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100">
                    <a href="Item.php?id=<?= $listProdLoisirs[$i]->id_produit; ?>">
                        <img class="img-responsive" src="<?= $listProdLoisirs[$i]->photo; ?>" alt=""
                             style="height: 150px;"/>
                    </a>
                    <div class="card-body">
                        <h4 class="card-title">
                            <a href="Item.php?id=<?= $listProdLoisirs[$i]->id_produit; ?>"><?= $listProdLoisirs[$i]->nom; ?></a>
                        </h4>
                        <h5><?= $listProdLoisirs[$i]->prix_jeton; ?> SwapCoin</h5>
                        <p class="card-text"><?= substr($listProdLoisirs[$i]->description, 0, 200); ?> ...</p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                    </div>
                </div>
            </div>
            </html>
        <?php }
    }
}

// ---------------------------------------------------------------
// PARTIE AFFICHAGE DRONE
// ---------------------------------------------------------------
function returnProduitDrone()
{
    {
        $bdd2 = null;
        $drone = "Drone";

        if ($bdd2 == null) {
            $bdd2 = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd2) {
            // Obtention de la liste des pays
            $resultat2 = $bdd2->query("SELECT * FROM produits WHERE libelle='$drone'");
            if ($resultat2) {
                $productListDrone= $resultat2->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat2->closeCursor();
            }
        }
        return $productListDrone;
    }
}

function countReturnProduitDrone()
{
    $bdd = null;
    $drone = "Drone";

    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // La bd est-elle valide ?
    if ($bdd) {
        // Obtention de la liste des pays
        $smtp2 = $bdd->query("SELECT COUNT(*) as count FROM produits WHERE libelle = '$drone'");
        if ($smtp2) {
            $countProductListDrone = $smtp2->fetchAll(PDO::FETCH_OBJ);
            // Fermeture de la ressource
            $smtp2->closeCursor();
        }
    }
    return $countProductListDrone;
}

function afficheProduitDrone($listProdDrone)
{
    $countDrone = (int)countReturnProduitDrone()[0]->count;
    for($i=0;$i<$countDrone;$i++) {
        if (($listProdDrone[$i]->dispo) == 0) { ?>
            <html>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100">
                    <a href="Item.php?id=<?= $listProdDrone[$i]->id_produit; ?>">
                        <img class="img-responsive" src="<?= $listProdDrone[$i]->photo; ?>" alt=""
                             style="height: 150px;"/>
                    </a>
                    <div class="card-body">
                        <h4 class="card-title">
                            <a href="Item.php?id=<?= $listProdDrone[$i]->id_produit; ?>"><?= $listProdDrone[$i]->nom; ?></a>
                        </h4>
                        <h5><?= $listProdDrone[$i]->prix_jeton; ?> SwapCoin</h5>
                        <p class="card-text"><?= substr($listProdDrone[$i]->description, 0, 200); ?> ...</p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                    </div>
                </div>
            </div>
            </html>
        <?php }
    }
}

// -----------------------------------------------------------------------------------------------------------
// AFFICHER UN ITEM
// -----------------------------------------------------------------------------------------------------------
function returnItem($id_produit)
{
    {
        $bdd = null;

        if ($bdd == null) {
            $bdd = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd) {
            // Obtention de la liste des pays
            $resultat = $bdd->query("SELECT * FROM produits WHERE id_produit='$id_produit'");
            if ($resultat) {
                $productItem = $resultat->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat->closeCursor();
            }
        }
        return $productItem;
    }
}

function idAnnonceur($id_produit)
{
    {
        $bdd = null;

        if ($bdd == null) {
            $bdd = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd) {
            // Obtention de la liste des pays
            $resultat = $bdd->query("SELECT id_utilisateur FROM produits WHERE id_produit='$id_produit'");
            if ($resultat) {
                $id_user = $resultat->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat->closeCursor();
            }
        }
        return $id_user;
    }
}

function infoAnnonceur($id)
{
    {
        $bdd = null;

        if ($bdd == null) {
            $bdd = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd) {
            // Obtention de la liste des pays
            $resultat = $bdd->query("SELECT * FROM utilisateurs WHERE id_utilisateur='$id'");
            if ($resultat) {
                $infoUser = $resultat->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat->closeCursor();
            }
        }
        return $infoUser;
    }
}


function afficheItem($id_produit)
{
    $prodItem = returnItem($id_produit);
    $id = $prodItem['0']->id_utilisateur;
    $infoAnnonceur = infoAnnonceur($id);
    ?>
    <div class="col-lg-2">
        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-8">

          <div class="card mt-4">
              <img class="img-responsive" src="<?=$prodItem['0']->photo;?>" alt="" style="width: 300px;height: 260px;"/>
            <div class="card-body">
                <h3 class="card-title"><u><?=$prodItem['0']->nom;?></u></h3>
                <h4><b><?=$prodItem['0']->prix_jeton;?></b> SwapCoin</h4>
                <p class="card-text"><?=$prodItem['0']->description;?></p>
                <p class="card-text"><h5><b><u>Etat</u>  : <?=$prodItem['0']->etat;?></b></h5></p>
                <span class="text-warning">&#9733; &#9733; &#9733; &#9733; &#9734;</span>4.0 stars
            </div>
          </div>
            <!-- /.card -->

            <div class="card card-outline-secondary my-4">
                <div class="card-header">
                    <b>Information sur l'annonceur</b>
                </div>
                <div class="card-body">
                    <p class="card-text"><h6><b><u><i>Nom</i></u>  : <?=$infoAnnonceur['0']->nom;?></b></h6></p>
                    <hr>
                    <p class="card-text"><h6><b><u><i>Prenom</i></u>  : <?=$infoAnnonceur['0']->prenom;?></b></h6></p>
                    <hr>
                    <p class="card-text"><h6><b><u><i>Ville</i></u>  : <?=$infoAnnonceur['0']->ville;?></b></h6></p>
                    <hr>
                    <?php
                    if (isset($_SESSION['email'])) {
                        ?>
                    <a href="achat.php?id=<?=$prodItem['0']->id_produit;?>" class="btn btn-success">Acheter au prix de <?=$prodItem['0']->prix_jeton;?> SwapCoin</a>
                        <?php
                    }  else {
                    ?>
                    <a href="#" class="btn btn-secondary disabled">Acheter au prix de <?=$prodItem['0']->prix_jeton;?> SwapCoin</a>
                        <br/><br/>
                        <p style="font-size: 10px;text-align: right;">Vous devez vous <b><u>connecter</u></b> pour <b><u>acheter un objet</u></b>.</p>
                        <?php
                    }
                    ?>
                </div>
            </div>
<!-- /.card -->

        </div>
<!-- /.col-lg-8 -->
<div class="col-lg-2">
</div>
<?php }

function editProfile($nom_edit, $prenom_edit, $mdp_edit, $adresse1_edit, $adresse2_edit, $cp_edit, $ville_edit, $pays_edit, $id) {
    $bdd = getDataBase();
    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // BDD valide ?
    if (isset($bdd)) {
        // Insertion dans la BDD
        $stmt = $bdd->prepare("UPDATE utilisateurs
            SET nom = '$nom_edit', prenom = '$prenom_edit', mdp = '$mdp_edit', adresse1 = '$adresse1_edit', adresse2 = '$adresse2_edit', cp = '$cp_edit', ville = '$ville_edit', pays = '$pays_edit'
            WHERE id_utilisateur = '$id'");
        $stmt->execute();
        ?>
        <html>
        <!-- Page Content -->
        <div class="container">
            <div class="row">
                <h1 class="my-4 text-uppercase">Vos informations <b style="color: green;"><u>ont été mise à jour</u></b>.
                    <br/> Vous allez être redirigé dans 3 secondes...</h1>
            </div>
        </div>
        </html>
        <?php
    }
    else {
            ?>
            <html>
            <!-- Page Content -->
            <div class="container">
                <div class="row">
                    <h1 class="my-4 text-uppercase">Une <u>erreur</u> s'est produite.
                        <br/> Vos informations <b style="color: red;"><u>n'ont pas été mise à jour</u></b>.
                        <br/> Vous allez être redirigé dans 3 secondes...</h1>
                </div>
            </div>
            </html>
            <?php
        }

}

function achatItem($id_produit, $id_acheteur)
{
    $prodItem = returnItem($id_produit);
    $id_vendeur = $prodItem['0']->id_utilisateur;
    $infoAnnonceur = infoAnnonceur($id_vendeur);
    $infoAcheteur = returnUtilisateur($id_acheteur);
    $nbrDeSwapCoinApresAchat = $infoAcheteur['0']->nombre_jeton - $prodItem['0']->prix_jeton;
    ?>

    <!-- /.col-lg-3 -->

    <div class="col-lg-8">

        <div class="card card-outline-secondary my-4">
            <div class="card-header">
                <b>Récapitulatif du produit</b>
            </div>
            <div class="card-body">
                <p class="card-text"><h6><b><u>NOM</u>  : <?=$prodItem['0']->nom;?></b></h6></p>
                <hr>
                <p class="card-text"><h6><b><u>PRIX</u>  : <?=$prodItem['0']->prix_jeton;?> SwapCoin</b></h6></p>
                <hr>
                <p class="card-text"><h6><b><u>DESCRIPTION</u>  : <?=$prodItem['0']->description;?></b></h6></p>
                <hr>
                <p class="card-text"><h6><b><u>ETAT</u>  : <?=$prodItem['0']->etat;?></b></h6></p>
                <hr>
                <p class="card-text"><h6><b><u>VENDU PAR</u>  : <?=$infoAnnonceur['0']->prenom;?> <?=$infoAnnonceur['0']->nom;?> de <i><?=$infoAnnonceur['0']->ville;?></i></b></h6></p>
                <br/>
                <hr color="black">
                <p class="card-text"><h6><b><u>VOTRE SOLDE ACTUEL</u>  :<br/><img src="./image/imgJeton.png" alt="Token" class="img-fluid" style="width: 50%;max-width: 35px;min-width: 25px; height: 50%; max-height: 35px; min-height: 25px;"/>
                        <strong style="color: red;"><?=$infoAcheteur['0']->nombre_jeton;?></strong></b></h6></p><hr color="black">
                <p class="card-text"><h6><b><u>VOTRE SOLDE <span style="color: green;">APRES ACHAT</span></u>  :<br/><img src="./image/imgJeton.png" alt="Token" class="img-fluid" style="width: 50%;max-width: 35px;min-width: 25px; height: 50%; max-height: 35px; min-height: 25px;"/>
                        <strong style="color: red;"><?php if (($infoAcheteur['0']->nombre_jeton) > ($prodItem['0']->prix_jeton)) { echo "$nbrDeSwapCoinApresAchat";} else {echo "$nbrDeSwapCoinApresAchat [Vous n'avez pas assez de SwapCoins.]";}?></strong></b></h6></p><hr color="black">
                <hr>
                <p class="card-text"><h6><b>&Agrave; noter que le vendeur a 24H pour accepter votre achat.<br/>
                        Pendant ce lapse de temps, l'objet est bloqué à votre nom.<br/>
                        Si le vendeur refuse votre achat ou si les 24H sont écoulées,<br/>
                        l'objet est remis en ligne et vos SwapCoins vous sont restitués.</b></h6></p><br/>
                <?php
                if (isset($_SESSION['email'])) {
                    if (($infoAcheteur['0']->nombre_jeton) > ($prodItem['0']->prix_jeton)) { ?>
                    <a href="achatController.php?id=<?=$id_produit?>" class="btn btn-success">Confimer l'achat</a>&nbsp;&nbsp;&nbsp;
                    <?php
                } else { ?>
                        <a href="#" class="btn btn-success disabled">Confimer l'achat</a>&nbsp;&nbsp;&nbsp;
                    <?php }
                } ?>
                        <a href="Item.php?id=<?=$id_produit?>" class="btn btn-danger">Annuler l'achat</a>

            </div>
        </div>
        <!-- /.card -->

    </div>
    <!-- /.col-lg-8 -->
    <div class="col-lg-2">
    </div>
<?php }

//----------------------------------------------------------------------------------------------------------------------
// FONCTIONS D'ACHAT, DE VERIFICATION DES 24H ECOULEES
//----------------------------------------------------------------------------------------------------------------------

function insertAchat($id_produit, $id_acheteur, $id_vendeur, $date_achat, $date_expiration)
{
    $bdd = getDataBase();
    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // BDD valide ?
    if (isset($bdd)) {
            // Insertion dans la BDD
            try { $stmt = $bdd->prepare("INSERT INTO achete (id_produit, id_acheteur, id_vendeur, date_achat, date_expiration, statut)
                                            VALUES( :pid_prod, :pid_acheteur, :pid_vendeur, :pdate_achat, :pdate_expiration, '1')");
            $stmt->bindParam(':pid_prod', $id_produit);
            $stmt->bindParam(':pid_acheteur', $id_acheteur);
            $stmt->bindParam(':pid_vendeur', $id_vendeur);
            $stmt->bindParam(':pdate_achat', $date_achat);
            $stmt->bindParam(':pdate_expiration', $date_expiration);
            $stmt->execute(); }
         catch(Exception $e) {
            die("Une erreur et survenue. Veuillez recommencer l'opération.");
        }
    }
}

function payeVendeur($id_vendeur, $prix_produit) {
    $bdd = getDataBase();
    $infoAnnonceur = infoAnnonceur($id_vendeur);
    $nombre_jeton = $infoAnnonceur['0']->nombre_jeton;
    $total = $prix_produit + $nombre_jeton;
    if ($bdd == null) {
        $bdd = getDataBase();
    }
    // BDD valide ?
    if (isset($bdd)) {
        // Insertion dans la BDD
        $stmt = $bdd->prepare("UPDATE utilisateurs
            SET nombre_jeton = '$total'
            WHERE id_utilisateur = '$id_vendeur'");
        $stmt->execute();
    }
}

function prelevementAcheteur($id_acheteur, $prix_produit) {
    $bdd = getDataBase();
    $infoAcheteur = returnUtilisateur($id_acheteur);
    $nombre_jeton_acheteur = $infoAcheteur['0']->nombre_jeton;
    $total_acheteur = $nombre_jeton_acheteur - $prix_produit;
    if ($bdd == null) {
        $bdd = getDataBase();
    }
    // BDD valide ?
    if (isset($bdd)) {
        // Insertion dans la BDD
        $stmt = $bdd->prepare("UPDATE utilisateurs
            SET nombre_jeton = '$total_acheteur'
            WHERE id_utilisateur = '$id_acheteur'");
        $stmt->execute();
    }
}

function changeDispoProd($id_produit) {
    $bdd = getDataBase();
    if ($bdd == null) {
        $bdd = getDataBase();
    }
    // BDD valide ?
    if (isset($bdd)) {
        // Insertion dans la BDD
        $stmt = $bdd->prepare("UPDATE produits
            SET dispo = '1'
            WHERE id_produit = '$id_produit'");
        $stmt->execute();
    }
}

function achatController($id_produit, $id_acheteur)
{
    $prodItem = returnItem($id_produit);
    $id_vendeur = $prodItem['0']->id_utilisateur;
    $infoVendeur = returnUtilisateur($id_vendeur);
    $infoAcheteur = returnUtilisateur($id_acheteur);
    $nbrDeSwapCoinApresAchat = $infoAcheteur['0']->nombre_jeton - $prodItem['0']->prix_jeton;
    $date_achat = date("Y-m-d H:i:s");
    $date_achat1 = date("m-d-Y H:i:s");
    $date_achat1 = str_replace('-', '/', $date_achat1);
    $date_expiration = date('Y-m-d H:i:s',strtotime($date_achat1 . "+1 days"));
    $date_expiration_view = date('d-m-Y H:i:s',strtotime($date_expiration));
    $prix_produit = $prodItem['0']->prix_jeton;
    $emailvendeur = $infoVendeur['0']->email;
    $nomproduit =  $prodItem['0']->nom;
    if ($nbrDeSwapCoinApresAchat >= 0) {
        insertAchat($id_produit, $id_acheteur, $id_vendeur, $date_achat, $date_expiration);
        payeVendeur($id_vendeur, $prix_produit);
        prelevementAcheteur($id_acheteur, $prix_produit);
        changeDispoProd($id_produit);
        envoiMailVendeur($emailvendeur, $nomproduit, $date_expiration_view);
        ?>
        <html>
    <div class="col-lg-8">
        <br/><br/>

        <div class="card card-outline-secondary my-4">
            <div class="card-header">
                <b>Vous avez acheté le produit <u><?=$prodItem['0']->nom;?></u>.</b>
            </div>
            <div class="card-body">
                <p class="card-text"><h6><u>&Agrave; NOTER QUE</u><br/><br/>
                    Le vendeur a 24H pour accepter votre achat.
                    Pendant ce lapse de temps, l'objet est bloqué à votre nom.<br/>
                    Si le vendeur refuse votre achat ou si les 24H sont écoulées, l'objet est remis en ligne et vos SwapCoins vous sont restitués.<br/>
                    <br/><br/>Lorque le vendeur aura répondu favorablement à votre achat, vous recevrez un <b><u>email de confirmation</u></b>.<br/>
                    Dans le cas où le vendeur aurait refuser votre achat ou que le lapse de temps de 24H serait écoulés,<br/>
                    vous recevrez un <b><u>email d'annulation d'achat</u></b>.</h6></p>
                <hr>
                <a href="index.php" class="btn btn-success">Retour à l'accueil</a>

            </div>
        </div>
        <!-- /.card -->

    </div>
    <!-- /.col-lg-8 -->
    <div class="col-lg-2">
    </div>
    </html>
        <?php
    } else {
        ?>
        <html>
        <div class="col-lg-8">
            <br/><br/>

            <div class="card card-outline-secondary my-4">
                <div class="card-body">
                    <p class="card-text"><h6>Une erreur et survenue.<br/>
                    Veuillez recommencer l'opération.</h6></p>
                    <hr>
                    <a href="index.php" class="btn btn-danger">Retour à l'accueil</a>

                </div>
            </div>
            <!-- /.card -->

        </div>
        <!-- /.col-lg-8 -->
        <div class="col-lg-2">
        </div>
        </html>
        <?php
    }
}

function envoiMailVendeur($email_vendeur, $nomproduit, $date_expiration_view) {
    $to      =  $email_vendeur;
    $subject = 'SwapConnect - Votre produit '.$nomproduit.' a trouve un acheteur !';
    $message = 'Bonjour,' . "\r\n" .
                'Le produit '.$nomproduit.' que vous avez mis en vente a trouve preneur !' . "\r\n" .
                'Vous avez 24H pour accepter ou refuser la vente. Après le '.$date_expiration_view.', votre produit sera automatiquement remis en vente.' . "\r\n" . "\r\n" .
                'A très vite !' . "\r\n" .
                'Merci de votre confiance,' . "\r\n" .
                'L\'equipe SwapConnect' . "\r\n" . "\r\n" .
                'Ceci est un email automatique, merci de ne pas y repondre.';
    $headers = 'From: swapconnectweb@gmail.com' . "\r\n" .
        'X-Mailer: PHP/' . phpversion();
    mail($to, $subject, $message, $headers);
}

function venteEnCours($id)
{
    {
        $bdd = null;

        if ($bdd == null) {
            $bdd = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd) {
            // Obtention de la liste des pays
            $resultat = $bdd->query("SELECT * FROM produits WHERE id_utilisateur='$id'");
            if ($resultat) {
                $venteEnCours = $resultat->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat->closeCursor();
            }
        }
        return $venteEnCours;
    }
}

function nbVenteEnCours($id)
{
    $bdd = null;

    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // La bd est-elle valide ?
    if ($bdd) {
        // Obtention de la liste des pays
        $smtp2 = $bdd->query("SELECT COUNT(*) as count FROM produits WHERE id_utilisateur = '$id'");
        if ($smtp2) {
            $countVenteEnCours = $smtp2->fetchAll(PDO::FETCH_OBJ);
            // Fermeture de la ressource
            $smtp2->closeCursor();
        }
    }
    return $countVenteEnCours;
}

function buttonVente($countVenteEnCours, $venteEnCours) {
    for($i=0;$i<$countVenteEnCours;$i++) {
        if (($venteEnCours[$i]->dispo)== '1') { ?>
            <b><?=$venteEnCours[$i]->nom;?> | Prix : <u><?=$venteEnCours[$i]->prix_jeton;?></u> SCs</b><span class="float-right"><a href="confirmationVente.php?id=<?=$venteEnCours[$i]->id_produit;?>" class="btn btn-success">Accepter l'offre</a>
                            <a href="annulationVente.php?id=<?=$venteEnCours[$i]->id_produit;?>" class="btn btn-danger">Refuser l'offre</a></span><br/><br/>
            <hr>
        <?php } elseif ($countVenteEnCours == 0) {?>
            <b>Aucune vente en cours.</b>
        <?php } else { ?>
            <b><?=$venteEnCours[$i]->nom;?> | Prix : <u><?=$venteEnCours[$i]->prix_jeton;?></u> SCs</b><span class="float-right"><a href="#" class="btn btn-secondary disabled">Aucune offre</a></span><br/><br/>
            <hr>
        <?php }
    }
}

function remiseEnVente($id_produit) {
    $bdd = null;

    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // La bd est-elle valide ?
    if ($bdd) {
        // Obtention de la liste des pays
        $smtp2 = $bdd->query("DELETE FROM achete WHERE id_produit = '$id_produit'");
        if ($smtp2) {
            // Fermeture de la ressource
            $smtp2->closeCursor();
        }
        $smtp3 = $bdd->query("UPDATE produits SET dispo = 0 WHERE id_produit = '$id_produit'");
        if ($smtp3) {
            // Fermeture de la ressource
            $smtp3->closeCursor();
        }
    }

}

function listAchete($id_produit) {
    $bdd = null;

    if ($bdd == null) {
        $bdd = getDataBase();
    }
    if ($bdd) {
        // Obtention de la liste des pays
        $smtp4 = $bdd->query("SELECT * FROM achete WHERE id_produit = '$id_produit'");
        if ($smtp4) {
            $listAchete = $smtp4->fetchAll(PDO::FETCH_OBJ);
            // Fermeture de la ressource
            $smtp4->closeCursor();
        }
    }
    return $listAchete;
}

function produitVendu($id_produit) {
    $bdd = null;
    $infoAchete = listAchete($id_produit);
    $id_vendeur = $infoAchete['0']->id_vendeur;
    $id_acheteur = $infoAchete['0']->id_acheteur;
    $date = date("Y-m-d  H:i:s");
    $infoProd = returnItem($id_produit);
    $nom_produit = $infoProd['0']->nom;
    $prix = $infoProd['0']->prix_jeton;
    $libelle = $infoProd['0']->libelle;
    $etat = $infoProd['0']->etat;
    $desc = $infoProd['0']->description;
    $photo = $infoProd['0']->photo;

    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // La bd est-elle valide ?
    if ($bdd) {
        $stmt = $bdd->prepare("INSERT INTO vente (id_vendeur, id_acheteur, date_vente, nom_produit, prix, libelle, etat, description, photo)
                                            VALUES( :pvendeur, :pacheteur, :pdate, :pnom_produit, :pprix, :plibelle, :petat, :pdesc, :pphoto)");
        $stmt->bindParam(':pvendeur', $id_vendeur);
        $stmt->bindParam(':pacheteur', $id_acheteur);
        $stmt->bindParam(':pdate', $date);
        $stmt->bindParam(':pnom_produit', $nom_produit);
        $stmt->bindParam(':pprix', $prix);
        $stmt->bindParam(':plibelle', $libelle);
        $stmt->bindParam(':petat', $etat);
        $stmt->bindParam(':pdesc', $desc);
        $stmt->bindParam(':pphoto', $photo);
        $stmt->execute();
        if ($stmt) {
            // Fermeture de la ressource
            $stmt->closeCursor();
        }
        $smtp2 = $bdd->query("DELETE FROM achete WHERE id_produit = '$id_produit'");
        if ($smtp2) {
            // Fermeture de la ressource
            $smtp2->closeCursor();
        }
        $smtp3 = $bdd->query("DELETE FROM produits WHERE id_produit = '$id_produit'");
        if ($smtp3) {
            // Fermeture de la ressource
            $smtp3->closeCursor();
        }
    }
}

function envoiMailAcheteurConfirm($email_acheteur, $nomproduit) {
    $to      =  $email_acheteur;
    $subject = 'SwapConnect - Le produit '.$nomproduit.' vous appartient !';
    $message = 'Bonjour,' . "\r\n" .
        'Le vendeur a accepte votre offre pour le produit '.$nomproduit.' !' . "\r\n" .
        'Votre produit arrivera sous 5 jours ouvrables (dès l\'envoi du colis de la part du vendeur) avec notre partenaire LivraisonTM' . "\r\n" . "\r\n" .
        'A très vite !' . "\r\n" .
        'Merci de votre confiance,' . "\r\n" .
        'L\'equipe SwapConnect' . "\r\n" . "\r\n" .
        'Ceci est un email automatique, merci de ne pas y repondre.';
    $headers = 'From: swapconnectweb@gmail.com' . "\r\n" .
        'X-Mailer: PHP/' . phpversion();
    mail($to, $subject, $message, $headers);
}

function envoiMailAcheteurCancel($email_acheteur, $nomproduit) {
    $to      =  $email_acheteur;
    $subject = 'SwapConnect - Le produit '.$nomproduit.' a ete remis en vente...';
    $message = 'Bonjour,' . "\r\n" .
        'Le vendeur du produit '.$nomproduit.' n\'a pas accepte votre offre.' . "\r\n" .
        'Le produit a ete remis en vente. Vous pouvez donc retenter de l\'obtenir !' . "\r\n" . "\r\n" .
        'A très vite !' . "\r\n" .
        'Merci de votre confiance,' . "\r\n" .
        'L\'equipe SwapConnect' . "\r\n" . "\r\n" .
        'Ceci est un email automatique, merci de ne pas y repondre.';
    $headers = 'From: swapconnectweb@gmail.com' . "\r\n" .
        'X-Mailer: PHP/' . phpversion();
    mail($to, $subject, $message, $headers);
}

function recherche($recherche) {
    {
        $bdd = null;

        if ($bdd == null) {
            $bdd = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd) {

            $resultat = $bdd->query("SELECT * FROM produits WHERE nom LIKE '%{$recherche}%'");
            if ($resultat) {
                $infoRecherche = $resultat->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat->closeCursor();
            }
        }
        return $infoRecherche;
    }
}

function countRecherche($recherche) {
    $bdd = null;

    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // La bd est-elle valide ?
    if ($bdd) {
        // Obtention de la liste des pays
        $smtp2 = $bdd->query("SELECT COUNT(*) as count FROM produits WHERE nom LIKE '%{$recherche}%'");
        if ($smtp2) {
            $countRech = $smtp2->fetchAll(PDO::FETCH_OBJ);
            // Fermeture de la ressource
            $smtp2->closeCursor();
        }
    }
    return $countRech;
}

function afficheRecherche($recherche)
{
    $countRecherche = (int)countRecherche($recherche)[0]->count;
    $rechercheProd = recherche($recherche);
    for($i=0;$i<$countRecherche;$i++)
    {
        if (($rechercheProd[$i]->dispo) == 0) {?>
            <html>
            <div class="col-lg-12 col-md-6 mb-4">
                <div class="card h-100">
                    <a href="Item.php?id=<?=$rechercheProd[$i]->id_produit;?>">
                        <img class="card-img-top" src="<?=$rechercheProd[$i]->photo;?>" alt="" style="width: 200px;height: 150px;"/>
                    </a>
                    <div class="card-body">
                        <h4 class="card-title">
                            <a href="Item.php?id=<?=$rechercheProd[$i]->id_produit;?>"><?=$rechercheProd[$i]->nom;?></a>
                        </h4>
                        <h5><?=$rechercheProd[$i]->prix_jeton;?> SwapCoin</h5>
                        <p class="card-text"><?=substr($rechercheProd[$i]->description, 0, 100);?> ...</p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                    </div>
                </div>
            </div>
            </html>
            <?php
        }
    }
    if ($countRecherche == 0) { ?>
        <html>
    <div class="col-lg-12" style="text-align: center;padding-top: 25px;">
        <br/><br/><br/><br/>
        <b><u>Aucun produit</u> ne correspond &agrave; votre recherche...</b>
        <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
    </div>
    </html>
    <?php }
}

function venteEnCoursAdmin()
{
    {
        $bdd = null;

        if ($bdd == null) {
            $bdd = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd) {
            // Obtention de la liste des pays
            $resultat = $bdd->query("SELECT * FROM achete");
            if ($resultat) {
                $venteEnCoursAdmin = $resultat->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat->closeCursor();
            }
        }
        return $venteEnCoursAdmin;
    }
}

function nbVenteEnCoursAdmin()
{
    $bdd = null;

    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // La bd est-elle valide ?
    if ($bdd) {
        // Obtention de la liste des pays
        $smtp2 = $bdd->query("SELECT COUNT(*) as count FROM achete");
        if ($smtp2) {
            $countVenteEnCoursAdmin = $smtp2->fetchAll(PDO::FETCH_OBJ);
            // Fermeture de la ressource
            $smtp2->closeCursor();
        }
    }
    return $countVenteEnCoursAdmin;
}

function buttonVenteAdmin($countVenteEnCoursAdmin, $venteEnCoursAdmin)
{
    for ($i = 0; $i < $countVenteEnCoursAdmin; $i++) {
        ?>
            <b>ID Acheteur : <?= $venteEnCoursAdmin[$i]->id_acheteur; ?> | ID Vendeur : <?= $venteEnCoursAdmin[$i]->id_vendeur; ?> | Expire le : <u><?= $venteEnCoursAdmin[$i]->date_expiration; ?></u></b>
        <br/><br/>
            <hr>
            <?php
        }
}

function buttonVenteAdmin2($countVenteEnCoursAdmin2, $venteEnCoursAdmin2)
{
    for ($i = 0; $i < $countVenteEnCoursAdmin2; $i++) {
        ?>
        <b>Produit :</b> <?= $venteEnCoursAdmin2[$i]->nom; ?> | Prix : <?= $venteEnCoursAdmin2[$i]->prix_jeton; ?><br/><br/>
        <b>Description :</b> <?= $venteEnCoursAdmin2[$i]->description; ?><br/><br/>
        <b>Photo :</b> <img src="<?= $venteEnCoursAdmin2[$i]->photo;?>" style="max-width: 150px;max-height: 100px;"/>
        <a href="annulationVenteAdmin.php?id=<?= $venteEnCoursAdmin2[$i]->id_produit; ?>"
           class="btn btn-danger">Supprimer l'offre</a><br/><br/>
        <hr>
        <?php
    }
}

function suppressionProduitAdmin($id_produit) {
    $bdd = null;
if ($bdd == null) {
    $bdd = getDataBase();
}

    // La bd est-elle valide ?
    if ($bdd) {
        $smtp2 = $bdd->query("DELETE FROM produits WHERE id_produit = '$id_produit'");
        if ($smtp2) {
            // Fermeture de la ressource
            $smtp2->closeCursor();
        }
    }
}

function venteEnCoursAdmin2()
{
    {
        $bdd = null;

        if ($bdd == null) {
            $bdd = getDataBase();
        }

        // La bd est-elle valide ?
        if ($bdd) {
            // Obtention de la liste des pays
            $resultat = $bdd->query("SELECT * FROM produits");
            if ($resultat) {
                $venteEnCoursAdmin2 = $resultat->fetchAll(PDO::FETCH_OBJ);
                // Fermeture de la ressource
                $resultat->closeCursor();
            }
        }
        return $venteEnCoursAdmin2;
    }
}

function nbVenteEnCoursAdmin2()
{
    $bdd = null;

    if ($bdd == null) {
        $bdd = getDataBase();
    }

    // La bd est-elle valide ?
    if ($bdd) {
        // Obtention de la liste des pays
        $smtp2 = $bdd->query("SELECT COUNT(*) as count FROM produits");
        if ($smtp2) {
            $countVenteEnCoursAdmin2 = $smtp2->fetchAll(PDO::FETCH_OBJ);
            // Fermeture de la ressource
            $smtp2->closeCursor();
        }
    }
    return $countVenteEnCoursAdmin2;
}