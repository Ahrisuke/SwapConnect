<?php
include("Header.php");
include("Model.php");
$id_produit = htmlspecialchars($_GET["id"]);
?>

  <body>

    <!-- Page Content -->
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
            </div>
            <div class="col-lg-12" style="text-align: center;padding-top: 25px;">
                <a href="Sport.php" class="btn btn-light text-uppercase font-weight-bold">Sport</a>
                <a href="Mobilite.php" class="btn btn-light text-uppercase font-weight-bold">Mobilite</a>
                <a href="Domotique.php" class="btn btn-light text-uppercase font-weight-bold">Domotique</a>
                <a href="Accessoire.php" class="btn btn-light text-uppercase font-weight-bold">Accessoire</a>
                <a href="Multimedia.php" class="btn btn-light text-uppercase font-weight-bold">Multimedia</a>
                <a href="Loisirs.php" class="btn btn-light text-uppercase font-weight-bold">Loisirs</a>
                <a href="Drone.php" class="btn btn-light text-uppercase font-weight-bold">Drone</a><br><br>
            </div>

            <?php afficheItem($id_produit); ?>
        </div>

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright Hadrien HURET et Yohan Angelini &copy; SwapConnect 2018</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="startbootstrap-shop-item-gh-pages/vendor/jquery/jquery.min.js"></script>
    <script src="startbootstrap-shop-item-gh-pages/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>
