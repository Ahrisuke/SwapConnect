<?php
/**
 * Created by PhpStorm.
 * User: hadri
 * Date: 15/11/2018
 * Time: 22:39
 */
include("Header.php");
include("Model.php");
$id = $_SESSION ['id_user'];
if ($id == 21) {
    $id_produit = htmlspecialchars($_GET["id"]);
    suppressionProduitAdmin($id_produit);
    ?>
    <div style="text-align: center;">
        <br/><br/><br/><br/>
        <b>Produit Supprimé de la base de données.</b><br/><br/>
        <a href="admin.php"
           class="btn btn-danger">Retour Page Administrateur</a>
    </div>
    <?php
} else {
    echo "Vous n'etes pas administrateur";
}