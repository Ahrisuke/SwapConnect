<?php
include("Header.php");
include("Model.php");
if (isset($_SESSION ['id_user'])) {

    $id = $_SESSION ['id_user'];
    if ($id == 21) {
        $venteEnCoursAdmin = venteEnCoursAdmin();
        $countVenteEnCoursAdmin = (int)nbVenteEnCoursAdmin()[0]->count;
        $venteEnCoursAdmin2 = venteEnCoursAdmin2();
        $countVenteEnCoursAdmin2 = (int)nbVenteEnCoursAdmin2()[0]->count;
        ?>

        <!-- Page Content -->
        <div class="container">

            <div class="row">

                <div class="col-lg-4">

                    <h1 class="my-4 text-uppercase">Espace Administrateur</h1>

                </div>
                <br/><br/>
                <div class="col-sm-12"><!--left col-->
                    <div class="card card-outline-secondary my-4">
                        <div class="card-header">
                            <b>PRODUITS EN VENTE</b>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php
                                buttonVenteAdmin2($countVenteEnCoursAdmin2, $venteEnCoursAdmin2)
                                ?>
                            </p>
                        </div>
                    </div>
                </div>
                <br/><br/>
                <div class="col-sm-12"><!--left col-->
                    <div class="card card-outline-secondary my-4">
                        <div class="card-header">
                            <b>ACHATS EN COURS</b>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php
                                buttonVenteAdmin($countVenteEnCoursAdmin, $venteEnCoursAdmin)
                                ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.container -->

        <!-- Footer -->
        <footer class="py-5 bg-dark">
            <div class="container">
                <p class="m-0 text-center text-white">Copyright Hadrien HURET &copy; SwapConnect 2018</p>
            </div>
            <!-- /.container -->
        </footer>

        <!-- Bootstrap core JavaScript -->
        <script src="/vendor/jquery/jquery.min.js"></script>
        <script src="/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        </body>

        </html>
        <?php
    } else {echo "Vous n'etes pas administrateur";}
} else {
    echo "Vous n'etes pas connecté";
}

