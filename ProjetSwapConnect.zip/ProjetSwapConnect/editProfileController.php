<?php
include ("Header.php");
include ("Model.php");
/**
 * Created by PhpStorm.
 * User: hadri
 * Date: 05/10/2018
 * Time: 14:34
 */


/** EDITION UTILISATEUR */

    $id = $_SESSION['id_user'];
    $utilisateur = returnUtilisateur($id);

    /** VARIABLES */
    if ((isset($_POST['inputNomEdit'])) AND (!empty($_POST['inputNomEdit']))){
        $nom_edit = $_POST['inputNomEdit'];
    } else {$nom_edit = $utilisateur['0']->nom;}
    if ((isset($_POST['inputPrenomEdit'])) AND (!empty($_POST['inputPrenomEdit']))) {
        $prenom_edit = $_POST['inputPrenomEdit'];
    } else {$prenom_edit = $utilisateur['0']->prenom;}
    if ((isset($_POST['inputMdpEdit'])) AND (!empty($_POST['inputMdpEdit']))) {
        $mdp_edit = $_POST['inputMdpEdit'];
    } else {$mdp_edit = $utilisateur['0']->mdp;}
    if ((isset($_POST['inputAdresse1Edit']))AND (!empty($_POST['inputAdresse1Edit']))) {
        $adresse1_edit = $_POST['inputAdresse1Edit'];
    } else {$adresse1_edit = $utilisateur['0']->adresse1;}
    if ((isset($_POST['inputAdresse2Edit']))AND (!empty($_POST['inputAdresse2Edit']))) {
        $adresse2_edit = $_POST['inputAdresse2Edit'];
    } else {$adresse2_edit = $utilisateur['0']->adresse2;}
    if ((isset($_POST['inputCpEdit'])) AND (!empty($_POST['inputCpEdit']))) {
        $cp_edit = $_POST['inputCpEdit'];
    } else {$cp_edit = $utilisateur['0']->cp;}
    if ((isset($_POST['inputVilleEdit'])) AND (!empty($_POST['inputVilleEdit']))){
    $ville_edit = $_POST['inputVilleEdit'];
    } else {$ville_edit = $utilisateur['0']->ville;}
    if ((isset($_POST['inputPaysEdit'])) AND (!empty($_POST['inputPaysEdit']))) {
    $pays_edit = $_POST['inputPaysEdit'];
    } else {$pays_edit = $utilisateur['0']->pays;}

    editProfile($nom_edit, $prenom_edit, $mdp_edit, $adresse1_edit, $adresse2_edit, $cp_edit, $ville_edit, $pays_edit, $id);
    header( "refresh:3;url=Profile.php" );