<?php
include("Header.php");
// l'utlisateteur vient-il de la page "connect.php" ?
if (isset($error) && $error == 1) {
    ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                    aria-hidden="true">&times;</span></button>
        L'identifiant ou le mot de passe est incorrect.
    </div>
    <?php
}
?>
<br/><br/>
<!-- Page Content -->
<div class="container">
<div class="row">
    <div class="col-lg-3">
    </div>
    <div class="col-lg-6">
        <h2>Connexion</h2>

        <form action="loginController.php" method="POST">
            <div class="form-group">
                <label for="Email">Email</label>
                <input type="text" class="form-control" name="email" placeholder="Entrez votre email"/>
            </div>
            <label for="Mdp">Mot de passe </label>
            <input type="password" class="form-control" name="mdp" placeholder="Entrez votre mot de passe"/>
            <br>
            <input type="submit" value="Se Connecter" class="btn btn-primary"/>

        </form>
    </div>
    <div class="col-lg-3">
    </div>

</div>
</div>
<!-- Bootstrap core JavaScript -->
<script src="/vendor/jquery/jquery.min.js"></script>
<script src="/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<!-- Footer -->
<footer class="py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright Hadrien HURET et Yohan Angelini &copy; SwapConnect 2018</p>
    </div>
    <!-- /.container -->
</footer>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>