<!DOCTYPE html>
<html>
<head>
    <title>S'inscrire</title>
    <?php
    include_once ("Header.php");
    ?>
</head>

<body style="overflow-x: hidden;">
<div class="row">
    <div class="col-lg-3">
    </div>
    <div class="col-lg-6">
        <br/><br/>
        <h2>S'inscrire</h2>

            <form action="AdhererController.php" method="POST"><br>
                <div class="form-row">
                    <div class="form-group col-md-5">
                        <label for="nom">Nom</label>
                        <input type="text" class="form-control" name="nom" id="nom" placeholder="Entrez votre nom" required />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="prenom">Prénom</label>
                        <input type="text" class="form-control" name="prenom" id="prenom" placeholder="Entrez votre prénom" required />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="mdp">Mot de passe</label>
                        <input type="password" class="form-control" name="mdp" id="mdp" placeholder="Entrez votre Mot de Passe" required />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="mdp">Confirmation du Mot de passe</label>
                        <input type="password" class="form-control" name="confirmmdp" id="confirmmdp" placeholder="Confirmer votre mot de passe" required />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="adresse1">Adresse 1</label>
                        <input type="text" class="form-control" name="adresse1" id="adresse1" placeholder="Entrez votre adresse" required />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="adresse2">Complément d'adresse (optionnelle)</label>
                        <input type="text" class="form-control" name="adresse2" id="adresse2" placeholder="Complément d'adresse" />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="cp">Code Postal</label>
                        <input type="number" class="form-control" name="cp" id="cp" placeholder="Entrez votre Code Postal" required />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="ville">Ville</label>
                        <input type="text" class="form-control" name="ville" id="ville" placeholder="Entrez votre ville" required />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="email">Email</label>
                        <input type="text" class="form-control" name="email" id="email" placeholder="Entrez votre email" required />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="pays">Pays</label>
                        <input type="text" class="form-control" name="pays" id="pays" placeholder="Entrez votre pays" required />
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">S'inscrire</button>
                <br/><br/>
            </form>
    </div>
    <div class="col-lg-3">
    </div>
</div>
<!-- Footer -->
<footer class="py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright Hadrien HURET et Yohan Angelini &copy; SwapConnect 2018</p>
    </div>
    <!-- /.container -->
</footer>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
