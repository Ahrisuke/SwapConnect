<?php
/**
 * Created by PhpStorm.
 * User: hadri
 * Date: 29/10/2018
 * Time: 03:41
 */
    include_once ("Header.php");
    include ("Model.php");
    $id = $_SESSION ['id_user'];
    $utilisateur = returnUtilisateur($id);
    ?>
<!-- Page Content -->
<div class="container">

    <div class="row">


            <h1 class="my-4 text-uppercase">Edition du profil</h1>

        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9" style="padding-top: 40px; padding-bottom: 60px;">

            <form action="editProfileController.php" method="POST"><br>
                <div class="form-row">
                    <div class="form-group col-md-5">
                        <label for="nom">Nom</label>
                        <input type="text" class="form-control" name="inputNomEdit" id="inputNomEdit" placeholder="<?=$utilisateur['0']->nom;?>" />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="prenom">Prénom</label>
                        <input type="text" class="form-control" name="inputPrenomEdit" id="inputPrenomEdit" placeholder="<?=$utilisateur['0']->prenom;?>" />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="mdp">Mot de passe</label>
                        <input type="password" class="form-control" name="inputMdpEdit" id="mdp" placeholder="<?=$utilisateur['0']->mdp;?>" />
                    </div>

                    <div class="form-group col-md-5">
                        <label for="adresse1">Adresse</label>
                        <input type="text" class="form-control" name="inputAdresse1Edit" id="inputAdresse1Edit" placeholder="<?=$utilisateur['0']->adresse1;?>" />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="adresse2">Complément d'adresse (optionnelle)</label>
                        <input type="text" class="form-control" name="inputAdresse2Edit" id="inputAdresse2Edit" placeholder="<?=$utilisateur['0']->adresse2;?>" />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="cp">Code Postal</label>
                        <input type="number" class="form-control" name="inputCpEdit" id="inputCpEdit" placeholder="<?=$utilisateur['0']->cp;?>" />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="ville">Ville</label>
                        <input type="text" class="form-control" name="inputVilleEdit" id="inputVilleEdit" placeholder="<?=$utilisateur['0']->ville;?>" />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="pays">Pays</label>
                        <input type="text" class="form-control" name="inputPaysEdit" id="inputPaysEdit" placeholder="<?=$utilisateur['0']->pays;?>" />
                    </div>
                    <div class="form-group col-md-5">
                        <label for="pays">Avatar</label>
                        <input type="file" class="form-control" name="fileToUpload" id="fileToUpload" disabled/>
                    </div>

                </div>
                <button type="submit" class="btn btn-primary">Editer les informations</button>
                <br/><br/>
            </form>
    </div>
    <div class="col-lg-3">
    </div>
</div>
<!-- Footer -->
<footer class="py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright Hadrien HURET &copy; SwapConnect 2018</p>
    </div>
    <!-- /.container -->
</footer>
</body>
</html>