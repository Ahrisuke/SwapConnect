<?php
include "Model.php";
include ("Header.php");

if (isset($_POST['nom']) )
{
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $adresse1 = $_POST['adresse1'];
    $adresse2 = $_POST['adresse2'];
    $cp = $_POST['cp'];
    $ville = $_POST['ville'];
    $email = $_POST['email'];
    $pays = $_POST['pays'];
    $mdp = $_POST ['mdp'];
    $confirmMdp = $_POST['confirmmdp'];
    if (($adresse2 != "") AND ($mdp === $confirmMdp)) {
        $result = ajUtilisateur($nom, $prenom, $adresse1, $adresse2, $cp, $ville, $email, $pays, $mdp);
    } elseif ($mdp === $confirmMdp) { $result = ajUtilisateur2($nom,$prenom,$adresse1,$cp,$ville,$email,$pays,$mdp);}
    else { ?>
        <html>
        <div class="row">
            <div class="col-lg-3">
            </div>
            <div class="col-lg-6">
                <br/><br/>
        <!-- Page Content -->
        <div class="container">
            <div class="row">
                <h1 class="my-4 text-uppercase">Votre mot de passe <b style="color: red;"><u>ne correspond pas</u> au mot de passe
                    de confirmation</b>.
                    <br/> Vous allez être redirigé dans 3 secondes...</h1>
            </div>
        </div>
        </html>
<?php header("refresh:3;url=AdhererView.php");
    }
}