<?php
include("Header.php");
include("Model.php");
$listProd = returnProduit();
$count = (int)countReturnProduit()[0]->count;
?>

<!-- Page Content -->
<div class="container">
    <br><br>
    <div class="row">

        <div class="col-lg-3">

        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-12 table-dark" style="text-align: center;padding-top: 20px;">
                <a href="Sport.php" class="btn btn-light text-uppercase font-weight-bold" style="margin-top: 5px;">Sport</a>
                <a href="Mobilite.php" class="btn btn-light text-uppercase font-weight-bold" style="margin-top: 5px;">Mobilite</a>
                <a href="Domotique.php" class="btn btn-light text-uppercase font-weight-bold" style="margin-top: 5px;">Domotique</a>
                <a href="Accessoire.php" class="btn btn-light text-uppercase font-weight-bold" style="margin-top: 5px;">Accessoire</a>
                <a href="Multimedia.php" class="btn btn-light text-uppercase font-weight-bold" style="margin-top: 5px;">Multimedia</a>
                <a href="Loisirs.php" class="btn btn-light text-uppercase font-weight-bold" style="margin-top: 5px;">Loisirs</a>
                <a href="Drone.php" class="btn btn-light text-uppercase font-weight-bold" style="margin-top: 5px;">Drone</a><br><br>
        </div>
        <div class="row">
            <?php afficheProduitIndex($listProd); ?>

        </div>
        <!-- /.row -->

    </div>
    <!-- /.col-lg-9 -->

</div>
<!-- /.row -->

</div>
<!-- /.container -->

<!-- Footer -->
<footer class="py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright Hadrien HURET et Yohan Angelini &copy; SwapConnect 2018</p>
    </div>
    <!-- /.container -->
</footer>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
