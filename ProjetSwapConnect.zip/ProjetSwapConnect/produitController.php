<?php
include ("Header.php");
include ("Model.php");
/**
 * Created by PhpStorm.
 * User: hadri
 * Date: 05/10/2018
 * Time: 14:34
 */


/** AJOUT DU PRODUIT */

    /** VARIABLES */
    if (isset($_POST['inputNom'])) {
        $nom_prod = $_POST['inputNom'];
    }
    if (isset($_POST['inputPrix'])) {
        $prix_prod = $_POST['inputPrix'];
    }
    if (isset($_POST['inputDesc'])) {
        $desc_prod = $_POST['inputDesc'];
    }
    if (isset($_POST['inputEtat'])) {
        $etat_prod = $_POST['inputEtat'];
    }
    if (isset($_POST['inputCategorie'])) {
        $cat = $_POST['inputCategorie'];
    }
// UPLOAD IMAGE
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        $uploadOk = 1;
    } else {
        echo "Le fichier n'est pas une photo.";
        $uploadOk = 0;
        header("refresh:3;url=produitView.php");
    }
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
    echo "Seulement les formats JPG, JPEG, PNG & GIF sont acceptés.";
    $uploadOk = 0;
    header("refresh:3;url=produitView.php");
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Une erreur est survenue : Votre photo n'a pas été téléchargé.";
    header("refresh:3;url=produitView.php");
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "";
    } else {
        echo "Une erreur est survenue : Votre photo n'a pas été téléchargé.";
        header("refresh:3;url=produitView.php");
    }
}
// FIN UPLOAD IMAGE

    $id_user = $_SESSION['id_user'];
    if ($uploadOk === 1) {
    ajouterProduit ($nom_prod, $prix_prod, $desc_prod, $etat_prod, $target_file, $cat, $id_user);
    ?>
<html>
<!-- Page Content -->
<div class="container">
    <div class="row">
        <h1 class="my-4 text-uppercase">Votre produit <b style="color: green;"><u>a bien été enregisté</u></b>.
            <br/> Vous allez être redirigé dans 3 secondes...</h1>
    </div>
</div>
</html>
<?php
    header("refresh:3;url=index.php");}