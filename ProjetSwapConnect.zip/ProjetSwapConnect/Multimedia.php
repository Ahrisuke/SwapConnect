<?php
include("Header.php");
include("Model.php");
$listProdMultimedia = returnProduitMultimedia();
$countMultimedia = (int)countReturnProduitMultimedia()[0]->count;
?>

    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <div class="col-lg-3">

          <h1 class="my-4 text-uppercase">Multimedia</h1>
            <div class="list-group">
                <a href="Sport.php" class="list-group-item text-uppercase font-weight-bold">Sport</a>
                <a href="Mobilite.php" class="list-group-item text-uppercase font-weight-bold">Mobilite</a>
                <a href="Domotique.php" class="list-group-item text-uppercase font-weight-bold">Domotique</a>
                <a href="Accessoire.php" class="list-group-item text-uppercase font-weight-bold">Accessoire</a>
                <a href="Multimedia.php" class="list-group-item text-uppercase font-weight-bold">Multimedia</a>
                <a href="Loisirs.php" class="list-group-item text-uppercase font-weight-bold">Loisirs</a>
                <a href="Drone.php" class="list-group-item text-uppercase font-weight-bold">Drone</a>
            </div>

        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">

            <div>
                <img class="img-fluid" src="image/multimedia.jpg" alt="First slide">
            </div>

            <div class="row">
                <?php afficheProduitMultimedia($listProdMultimedia); ?>
            </div>
          <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright Hadrien HURET et Yohan Angelini &copy; SwapConnect 2018</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
