<?php
include("Header.php");
include("Model.php");
//On récupère les informations du formulaire de connexion
$email=$_POST["email"];
$mdp=$_POST["mdp"];
$userObject=authenticateUser($email,$mdp);

//Si il existe on lui met le statut connecté par le booléen $connected
if($userObject){
    $connected = true;
    $id = $userObject->id_utilisateur;

}else{
    $connected = false;
}
//Si l'utilisateur est connecté on rentre dans la condition if
if ($connected){

    // On démarre sa session utilisateur
    session_start ();
    $_SESSION['email']=$email;
    $_SESSION['mdp']=$mdp;
    $_SESSION['id_user'] = $id;
    // On stocke le fait qu'il soit connecté dans la variable "usertype" de sa session
    $_SESSION['usertype'] = $connected;
    // On le renvoie vers sa page d'accueil utilisateur
    header("Location: index.php");
}
else{ ?>
    <html>
    <div style="text-align: center;">
        <br/><br/><br/><br/>
        <b>Le <u>nom d'utilisateur</u> [et/ou] le <u>mot de passe</u> [est/sont] incorrecte(s).</b>
    </div>
    </html>
<?php
    header( "refresh:2;url=loginView.php" );
}
?>