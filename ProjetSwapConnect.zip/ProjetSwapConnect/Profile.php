<?php
include("Header.php");
include("Model.php");
$id = $_SESSION ['id_user'];
$utilisateur = returnUtilisateur($id);
$venteEnCours = venteEnCours($id);
$countVenteEnCours = (int)nbVenteEnCours($id)[0]->count;
?>
<body>
<br/>
<div class="container bootstrap snippet">
    <div class="row">
        <div class="col-sm-12"><h1 class="text-uppercase"><?=$utilisateur['0']->nom;?> <?=$utilisateur['0']->prenom;?></h1></div>
    </div>
    <div class="row">
        <div class="col-sm-12"><!--left col-->
                <img src="http://ssl.gstatic.com/accounts/ui/avatar_2x.png" class="avatar img-circle img-thumbnail text-center" alt="avatar">
        </div><!--/col-3-->
        <br/><br/>
		<div class="col-sm-1">
		</div>
        <div class="col-sm-12"><!--left col-->
            <div class="card card-outline-secondary my-4">
                <div class="card-header">
                    <b>MES VENTES EN COURS</b>
                </div>
                <div class="card-body">
                    <p class="card-text">
                        <?php
                        buttonVente($countVenteEnCours, $venteEnCours)
                        ?>
                    </p>
                </div>
            </div>
        </div>
        <br/><br/>
        <div class="col-sm-12">
            <table class="table table-dark">
                <tbody>
                    <tr>
                        <th  scope="row">Nom</th>
                        <td><?=$utilisateur['0']->nom;?></td>
                    </tr>
                    <tr>
                        <th scope="row">Prenom</th>
                        <td><?=$utilisateur['0']->prenom;?></td>
                    </tr>
                    <tr>
                        <th scope="row">E-mail</th>
                        <td><?=$utilisateur['0']->email;?></td>
                    </tr>
                    <tr>
                        <th scope="row">Adresse</th>
                        <td><?=$utilisateur['0']->adresse1;?></td>
                    </tr>
                    <tr>
                        <th scope="row">Compl&eacute;ment d'Adresse&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                        <td><?=$utilisateur['0']->adresse2;?></td>
                    </tr>
                    <tr>
                        <th scope="row">Code Postal</th>
                        <td><?=$utilisateur['0']->cp;?></td>
                    </tr>
                    <tr>
                        <th scope="row">Ville</th>
                        <td><?=$utilisateur['0']->ville;?></td>
                    </tr>
                    <tr>
                        <th scope="row">Pays</th>
                        <td><?=$utilisateur['0']->pays;?></td>
                    </tr>
                    <tr>
                        <th scope="row">Solde de SwapCoins</th>
                        <td><img src="./image/imgJeton.png" alt="Token" class="img-fluid" style="width: 50%;max-width: 35px;min-width: 25px; height: 50%; max-height: 35px; min-height: 25px;"/>
                            <strong style="color: red;"><?=$utilisateur['0']->nombre_jeton;?></strong></td>
                    </tr>
                </tbody>
            </table><!--/table-->
            <a href="editProfileView.php" class="btn btn-primary">Editer mon profil</a><br/><br/>
        </div><!--/tab-content-->

    </div><!--/col-9-->
</div><!--/row-->
<!-- Footer -->
<footer class="py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright Hadrien HURET et Yohan Angelini &copy; SwapConnect 2018</p>
    </div>
    <!-- /.container -->
</footer>
</body>
