<?php
include("Header.php");
?>

    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <div class="col-lg-3">

          <h1 class="my-4 text-uppercase">Ajouter un produit</h1>

        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9" style="padding-top: 40px; padding-bottom: 60px;">

            <!-- FORMULAIRE AJOUT PRODUIT -->
            <form action="produitController.php" method="POST" enctype="multipart/form-data">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputNom">Nom du produit</label>
                        <input type="text" class="form-control" name="inputNom" id="inputNom" placeholder="Nom du produit" required />
                    </div>
                    <div class="form-group col-md-6">
                        <label for="inputPrix">Prix</label>
                        <input type="number" step="0.01" min="0" class="form-control" name="inputPrix" id="inputPrix" placeholder="Prix" required />
                    </div>

                    <div class="form-group col-md-4">
                        <label for="inputEtat">Etat</label>
                        <select name="inputEtat" id="inputEtat" class="form-control" required>
                        <option selected>Neuf</option>
                        <option>Bon</option>
                        <option>Moyen</option>
                        <option>Mauvais</option>
                        </select>
                    </div>
                    <div class="form-group col-md-8">
                        <label for="textareaDescription">Description</label>
                        <textarea class="form-control" name="inputDesc" id="inputDesc" rows="5" placeholder="Description" required></textarea>
                    </div>
                <div class="form-group col-md-4">
                    <label for="inputCategorie">Catégorie</label>
                    <select name="inputCategorie" id="inputCategorie" class="form-control" required>
                        <option selected value="Sport">Sport</option>
                        <option value="Mobilite">Mobilité</option>
                        <option value="Domotique">Domotique</option>
                        <option value="Accessoire">Accessoire</option>
                        <option value="Multimedia">Multimédia</option>
                        <option value="Loisirs">Loisirs</option>
                        <option value="Drone">Drone</option>
                    </select>
                </div>
                </div>
                <div class="form-group">
                        <label for="filePhoto">Photo</label>
                        <input type="file" class="form-control" name="fileToUpload" id="fileToUpload" />
                </div>
                <button type="submit" class="btn btn-primary">Mettre en vente !</button>
            </form>

        </div>
        <!-- /.col-lg-9 -->

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright Hadrien HURET &copy; SwapConnect 2018</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="/vendor/jquery/jquery.min.js"></script>
    <script src="/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
