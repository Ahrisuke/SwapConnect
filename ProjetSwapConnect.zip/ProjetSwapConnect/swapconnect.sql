-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  ven. 16 nov. 2018 à 13:58
-- Version du serveur :  5.7.21
-- Version de PHP :  5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `swapconnect`
--

-- --------------------------------------------------------

--
-- Structure de la table `achete`
--

DROP TABLE IF EXISTS `achete`;
CREATE TABLE IF NOT EXISTS `achete` (
  `id_produit` int(11) NOT NULL,
  `id_acheteur` int(11) NOT NULL,
  `id_vendeur` int(11) NOT NULL,
  `date_achat` timestamp NOT NULL,
  `date_expiration` timestamp NOT NULL,
  `statut` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_produit`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id_categorie` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(30) NOT NULL,
  PRIMARY KEY (`id_categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id_categorie`, `libelle`) VALUES
(1, 'Sport'),
(2, 'Mobilite'),
(3, 'Domotique'),
(4, 'Accessoire'),
(5, 'Multimedia'),
(6, 'Loisirs'),
(7, 'Drone');

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

DROP TABLE IF EXISTS `produits`;
CREATE TABLE IF NOT EXISTS `produits` (
  `id_produit` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(500) NOT NULL,
  `prix_jeton` float NOT NULL,
  `description` varchar(2000) NOT NULL,
  `etat` varchar(20) NOT NULL,
  `photo` varchar(500) DEFAULT NULL,
  `date_annonce` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `libelle` varchar(30) NOT NULL,
  `id_utilisateur` int(11) NOT NULL,
  `dispo` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_produit`),
  KEY `produits_utilisateurs0_FK` (`id_utilisateur`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `produits`
--

INSERT INTO `produits` (`id_produit`, `nom`, `prix_jeton`, `description`, `etat`, `photo`, `date_annonce`, `libelle`, `id_utilisateur`, `dispo`) VALUES
(1, 'Bracelet Sport iBrac', 120, 'Permet de savoir son rythme cardiaque', 'Neuf', 'https://i2.cdscdn.com/pdt2/6/2/0/1/300x300/auc2009538306620/rw/smart-watch-r-t28-frequence-cardiaque-gps-etanche.jpg', '2018-11-02 16:52:26', 'Sport', 21, 0),
(3, 'Frigo X Connect', 1800, 'Controle à distance la temperature du frigo', 'Neuf', 'https://image.darty.com/gros_electromenager/refrigerateur-congelateur-refrigerateur-cong/refrigerateur-congelateur_bas/samsung_rb33j3205ww_d1707244329775B_154058783.jpg', '2018-09-27 22:00:00', 'Domotique', 21, 0),
(4, 'Porte Clef Connecte', 40, 'Permet de retrouver ses clefs grace à une application', 'Bon', 'https://www.boutique-neoshop.fr/images/Image/Porte-clef-connecteNEO024.jpg', '2018-09-27 22:00:00', 'Accessoire', 21, 0),
(5, 'Tele OLED Connecte', 2999, 'Tres flexible. Permet d\'etre enroulle. Commande par le telephone', 'Moyen', 'http://media.connexion.fr/img/400/A1257E05-C7A9-4D05-8EBC-40F959FE3A29.jpg', '2018-09-27 22:00:00', 'Multimedia', 21, 0),
(6, 'Lego Connect', 79, 'Nouveaux lego connecté pour que votre enfant ne s\'ennuie jamais', 'Mauvais', 'https://ae01.alicdn.com/kf/HTB1yABRyMKTBuNkSne1q6yJoXXa1/Legoing-Technic-Series-2838Pcs-The-Hatchback-Type-R-MOC-Racing-Car-Motor-Control-Building-Block-Compatible.jpg_220x220q90.jpg', '2018-09-27 22:00:00', 'Loisirs', 21, 0),
(7, 'Drone R-Falcon HD', 599, 'Le R-Falcon HD est la parfaite combinaison de technologie et de simplicité : placez votre smartphone au centre de la radio-commande pour profiter pleinement du retour image en direct et actionnez les différentes fonctionnalités d’un simple clic. Grâce à cette même radio-commande, vous pouvez également déclencher la caméra wifi 720p de votre drone distance pour un résultat toujours impeccable !', 'Neuf', 'https://www.pnj.fr/wp-content/uploads/2017/05/drone-r-falcon-camera-planification-vol-direction-lock-e1504889086161.jpg', '2018-09-27 22:00:00', 'Drone', 1, 0),
(16, 'Velo Cookie Smart', 1900, 'WiFi et Bluetooth, GPS intégré, Carte SIM intégré, Design épuré et exclusif, Système lumineux 360° (phare avant/arrière/clignotant), Application dédiée, Système antivol', 'Neuf', 'https://boulanger.scene7.com/is/image/Boulanger/bfr_overlay?layer=comp&$t1=&$product_id=Boulanger/4897032085947_h_f_l_0&wid=350&hei=350', '2018-11-09 12:57:33', 'Mobilite', 21, 0),
(17, 'Chaussures de course UA HOVR™ Phantom pour homme', 140, 'Pour résumer, vous ne vous êtes jamais senti aussi bien dans une chaussure. Vous avez littéralement l\'impression que votre pied est enveloppé dans un oreiller, un oreiller si léger que vous en oubliez sa présence. Son intérieur moulé anatomiquement, son tour de cheville en maille douce et ses couches de rembourrage qui enveloppent le pied offrent un confort inégalé. Bref, lorsque vous enfilerez votre chaussure Under Armour HOVR™ Phantom, vous comprendrez pourquoi nous indiquons qu\'elle offre une expérience de course inédite. ', 'Neuf', 'https://underarmour.scene7.com/is/image/Underarmour/V5ProdWithBadge?rp=standard-10pad|pdpZoomDesktop&scl=0.50&fmt=jpg&qlt=85&resMode=sharp2&cache=on,off&bgc=f0f0f0&rect=0,0,1836,1950&$p_pos=475,480&$p_size=950,950&extendN=0,0,0,0&$p_src=is{Underarmour/3020972-306_DEFAULT}', '2018-11-09 13:55:31', 'Sport', 3, 0),
(18, 'Coros Omni Smart Cycling Helmet ', 199, 'OMNI Smart Cycling Helmet\r\n\r\nThe COROS OMNI smart cycling helmet is designed to help you get the most enjoyment and awareness out of your ride, while enhancing ultimate safety. With an innovative open ear bone condensing audio system, auto LED tail lights and Smart Remote, the OMNI delivers an utmost combination of ride safety and convenience.\r\n\r\nThe ability to connect with your smartphone allows for two-way audio communication and uploading your ride. Get instant accessibility with the included Smart Remote to change music tracks, adjust volume, turn on/off your LED lights, or answer a phone call.', 'Neuf', 'https://images-na.ssl-images-amazon.com/images/I/61TFh44I5zL._SL1000_.jpg', '2018-11-09 14:00:30', 'Sport', 3, 0),
(19, 'Trottinette électrique et connectée Xiaomi M365', 300, 'Cette trottinette électrique en aluminium est très élégante malgré son poids de 12,5 kilos. Son moteur de 500 Watts offre une vitesse de 25km/h et permet de monter des côtes de 15 degrés. Elle peut couvrir une distance de 30 kilomètres soit une heure d’usage. Il faudra en revanche compter 5h30 pour charger cette batterie à 100%.\r\n\r\nOn regrettera aussi l’impossibilité de régler la hauteur du poste de pilotage, votre taille doit être comprise entre 1,70 et 1,75 mètre. Autre point faible de ce modèle : l’impossibilité de replier les poignées. De plus, il n’y a pas d’écran LCD sur le guidon, mais une application compagnon Mi Home pour smartphone est disponible. cependant malgré ces défauts la Xiaomi reste un très bonne trottinette, confortable et élégante.\r\n\r\nFiche technique :\r\n\r\n    Marque : Xiaomi\r\n    Poids : 12,5 kilos\r\n    Capacité : 100 kilos\r\n    Taille des roues : 8,5 pouces\r\n    Vitesse maximale : 25 km/h\r\n    Autonomie : 1 heure\r\n    Âge minimum : 14 ans', 'Neuf', 'https://www.objetconnecte.net/wp-content/uploads/2018/06/xiaomi-m365.jpg', '2018-11-09 14:10:00', 'Mobilite', 3, 0),
(20, 'ACTON R10 RocketSkates - The World\'s First Smart Electric Skates (Black) ', 250, 'These are the motorized electric roller skates that propel a wearer at up to 12 mph. Two sets of step-in footplates secure most types of footwear with strap bindings similar to those on snowboard boots, accommodating small and large feet. Supporting riders up to 250 lbs., each skate’s twin 6\"-diam. wheels has a 55-watt motor integrated into its fiber-reinforced nylon frame. Tilting forward on the toes accelerates while tilting back on the heel gently brakes. The footplates also pivot down to put your foot in contact with the ground for walking or going upstairs. Each skate has a removable lithium-ion battery that provides up to 1 1/2 hours of continuous power (up to a 10-mile range), ideal for travel across a school campus, to a local cafe, or while roaming a neighborhood festival. Batteries recharge in 2.5 hours using the included AC adapter. Model R10 Black. ', 'Neuf', 'https://i0.wp.com/www.notanygadgets.com/wp-content/uploads/2016/07/Rocket-Skates-4.jpg?fit=573%2C559&ssl=1', '2018-11-09 14:15:57', 'Mobilite', 4, 0),
(21, 'iRobot Roomba 691 Aspirateur Robot, système de nettoyage puissant avec Dirt Detect, aspire tapis, moquettes et sols durs, connexion Wi-Fi, argent', 339, 'Programmez et lancez le nettoyage d\'où que vous soyez avec l\'application iRobot HOME. Les capteurs de poussières permettent au Roomba 691 d\'insister d\'avantage sur les zones les plus sales, comme les parties les plus fréquentées de votre maison. Le système de nettoyage en 3 étapes récupère tout type de saleté, de fines particules de poussières jusqu\'aux débris plus larges. Idéal pour les poils d\'animaux, la tête de nettoyage adapte automatiquement son hauteur pour nettoyer efficacement et les sols durs et les tapis & moquettes. La seule marque leader dans la catégorie de robots aspirateurs à proposer 2 brosses de nettoyage, une pour décoller la saleté et l\'autre pour bien la récupérer.. Une suite complète de capteurs guide Roomba 691 sous et autours des meubles afin de vous aider à nettoyer parfaitement vos sols, jusqu\'à dans les coins. Conçu par le leader mondial des robots de nettoyage, fort de plus de 25 ans d’expertise robotique et innovation', 'Neuf', 'https://www.bestofrobots.fr/media/catalog/product/cache/1/image/800x/9df78eab33525d08d6e5fb8d27136e95/r/o/roomba_691_-_vue_de_c_t_2.jpg', '2018-11-09 14:22:02', 'Domotique', 4, 0),
(22, 'Tondeuse robot connectée WORX M800 wifi, 800 m² ', 999.99, 'Robot connecté, programmable à distance.\r\n\r\nRobot de tonte autonome dédié à la tonte des terrains avec des pentes jusqu’à 35%, pouvant circuler dans les zones étroites de votre jardin. Possibilité de programmer jusqu’à 4 zones de tonte. Application pour contrôle robot avec Smartphone. Technologie de coupe AIA (Artificial Intelligence Algorithm). Coupe 30% plus rapidement que n’importe quel modèle concurrent. Retourne automatiquement à sa base de recharge quand la batterie en a besoin. Système de coupe triples lames avec système Mulching. Capteur de pluie : avertit le robot quand retourner à sa station de charge. Blocage de sécurité au moyen code PIN, Bips d’erreur ou de soulèvement. 2 moteurs Brushless (sans charbons). Batterie de Lithium-ion : meilleure capacité de charge, plus d’autonomie, pas ou peu d’autodécharge, pas d’effet de mémoire, plus légère.', 'Neuf', 'https://s1.lmcdn.fr/multimedia/fb1500707685/36c1558e25633/produits/tondeuse-robot-connectee-worx-m800-wifi-800-m2.jpg?$p=hi-w795', '2018-11-09 14:27:15', 'Domotique', 4, 0),
(23, 'Mavic Air Fly More Combo & DJI Goggles - Arctic White', 1499.99, 'DJI poursuit sa quête de \"transportabilité\" et offre au Mavic Air la possibilité de replier ses quatre bras pour se glisser partout. Encore plus petit que le Mavic Pro avec 168 x 83 x 49 mm replié contre 198 x 83 x 83 (L×l×H), le Mavic Air se range dans n\'importe quel sac ou grande poche de veste. Pour vous donner un ordre d\'idée, si nous comparons le Mavic Pro à un reflex sans objectif, le Mavic Air a quant à lui l\'encombrement d\'un hybride. Même constat pour la radiocommande, minuscule, dont nous apprécions les joysticks amovibles qui facilitent encore le transport.', 'Neuf', 'https://cdn.shopify.com/s/files/1/2439/3765/products/Mavic_Air_Goggle_Fly_More_Combo_Arctic_White_8a41fec6-8511-45fd-a3dc-5407fb0e7b3b_1090x@2x.png?v=1527482851', '2018-11-09 14:35:17', 'Drone', 4, 0),
(24, ' Drone Parrot DISCO FPV ', 299.99, 'Parrot Disco FPV est un drone volant au design innovant, capable de haute performance en terme de maniabilité et de vitesse.\r\nAppréciez son aérodynamisme avec un comportement similaire à un avion, son mode autopilote avancé, sa  résistance aux chocs et au vent. Le Parrot Disco est capable d\'une  vitesse incroyable de 80 km/h et bénéficie d\'une grande  autonomie, allant jusqu\'à 45 minutes !\r\nImmortalisez votre vol avec sa  caméra Full HD embarquée avec  stabilisation numérique sur 3 axes et profitez d\'une qualité exceptionnelle de  14 millions de pixels !  ', 'Neuf', 'https://image.darty.com/telephonie/drone/drone/parrot_disco_fpv_mpp_k1608194253876A_173038835.jpg', '2018-11-09 14:44:55', 'Drone', 4, 0),
(25, ' Enceinte intelligente Google HOME MAX GALET ', 399.99, 'Redécouvrez votre musique\r\n\r\nAvec ses composants sophistiqués  la nouvelle enceinte Google Home Max restitue votre musique de façon optimale pour une qualité audio haute fidélité. Deux boomers (haut-parleurs de grave) de 11,4 cm diffusent des basses intenses et équilibrées tandis que les tweeters (haut-parleurs aigus) révèlent des aigus d\'une clarté cristalline. ', 'Neuf', 'https://image.darty.com/audio_mp3_mp4/enceinte_ipod_ipad_iphone_mp3/enceinte_intelligente/google_google_home_max_blc_k1809034568010B_093723626.jpeg', '2018-11-09 14:48:09', 'Multimedia', 1, 0),
(26, 'Barre de son Bose Soundbar 700', 899.99, 'NE VOUS CONTENTEZ PAS D’ÉCOUTER.\r\nRESSENTEZ CHAQUE INSTANT.\r\n\r\nVous ne souhaitez pas seulement entendre votre musique, vos films et vos émissions télévisées. Vous souhaitez ressentir les pas lourds du dinosaure à l’écran, la clameur de la foule lorsque les outsiders gagnent le match, ou vibrer au son de votre musique préférée. C’est pourquoi nous avons décidé de concevoir la meilleure barre de son au monde, la Bose Soundbar 700. Avec une combinaison inédite d’un design sophistiqué et d’une qualité sonore exceptionnelle, cette barre de son compacte réunit ce qui se fait de mieux pour vous faire ressentir la puissance de chaque moment de votre divertissement. Et avec Alexa intégrée, toute votre musique est diffusée à votre demande.\r\n\r\nAu-delà du son, une expérience complète. Alors, venez nous voir et testez-la vous-même !', 'Neuf', 'https://assets.bose.com/content/dam/Bose_DAM/Web/consumer_electronics/global/products/speakers/bose_soundbar_700/images/SB700_3x2_looks_as_good.psd/jcr:content/renditions/cq5dam.web.1000.1000.jpeg', '2018-11-09 15:02:49', 'Multimedia', 1, 0),
(27, 'Le bateau télécommandé qui tracte les jet-skieur', 19000, 'This is the unmanned water skiing boat that\'s controlled entirely by the skier.\r\n\r\nA six-button control panel on the tow rope handle sends signals to the boat, allowing skiers to start, accelerate, decelerate, turn, or stop the vessel with slight thumb movements.\r\n\r\nThe nearly 8\'-long boat has a three-cylinder, two-stroke 70 horsepower engine with jet pump and axial flow propulsion, generating speeds up to 40 MPH and creating wakes for jumps and other tricks. The jet propulsion engine is safer than propeller-powered crafts and provides superior acceleration and quicker planing--the time required to bring the skier and vessel level with the water surface.\r\n\r\nMade from durable fiberglass and molded plastic with a bilge pump that automatically removes water from the vessel.\r\n\r\nThe boat has a six-gallon gas tank and automatically stops when the skier lets go of the handle.\r\n\r\nIncludes a 40\'-long tow rope.\r\n\r\nFor use in water that\'s at least 6\' deep, the boat is also ideal for slalom skiing, knee boarding, wake boarding, or tubing.', 'Neuf', 'https://theawesomer.com/photos/2011/04/041811_self_piloted_tow_boat_2.jpg', '2018-11-09 15:07:50', 'Loisirs', 1, 0),
(28, ' Masque pour Caméra MEDIACOM M-SKIMASK FullHD IP x 44', 199.99, ' Si vous êtes passioné d\'informatique et d\'électronique, si vous êtes à la pointe de la technologie et qu\'aucun détail ne vous échappe, achetez Masque pour Caméra Sportive MEDIACOM M-SKIMASK FullHD IP x 44 au meilleur prix.', 'Neuf', 'http://www.equipement-ski.fr/wp-content/uploads/2015/12/equipement-ski-masque-de-ski-numerique-2.jpg', '2018-11-09 15:26:15', 'Accessoire', 1, 0),
(29, 'Proto X Nano RC Quadcopter', 69, 'This tiny remote control quadcopter has a plastic body with a window and trim detail with LED lights on the front and back that help in low light flying\r\n\r\nEach order includes:\r\n\r\n- RTF Proto X Nano Quadcopter.\r\n- 2.4GHz Radio.\r\n- LiPo Battery.\r\n- USB Charge Cord.\r\n- 4 spare rotor blades.\r\n- Instructions\r\n\r\nRequires: AAA Batteries (2 for the transmitter)\r\n\r\nPlease allow 7-10 days for shipping.', 'Neuf', 'https://thefancy-media-ec3.thefancy.com/1280/20131228/526985840430155338_508e07bafbd7.jpg', '2018-11-09 15:28:10', 'Drone', 1, 0),
(30, 'Oakley Airwave 1.5 Smart Goggles', 699, 'Vous projette directement la température, votre vitesse, la distance et hauteur de vos sauts. Mais est également muni de wifi et bluetooth le reliant à votre iphone, et vous permet de voir votre playlist, vos messages et appels entrant. Le tout relié à une mini manette qui vous permet de contrôler tout ça. Il est aussi équipé d\'un GPS.', 'Neuf', 'https://thefancy-media-ec5.thefancy.com/1280/20131015/473546827002551317_e2c388d1df95.jpg', '2018-11-09 15:29:22', 'Sport', 1, 0),
(31, ' Cardiff Skate Co. Adult S-Series Skates ', 259, 'Les S1 et les S2 ont un châssis triangulaire en métal qui accueille une roue de 80 mm à l\'avant et deux roues de 90 mm sur les côtés. Il existe bien une roue à l\'arrière, mais elle sert de frein ! La plateforme où repose le pied est équipée d\'une butée pour venir caler la pointe de la chaussure. Le talon va venir se bloquer dans une structure plastique souple.\r\nLe design noir à peine rehaussée de bleu ou de orange est discret. L\'ensemble inspire une grande confiance tant les matériaux choisis semblent solides. Cette fabrication US, c\'est du costaud ! Le fabricant n\'a pas lésiné sur la qualité.', 'Neuf', 'https://images-na.ssl-images-amazon.com/images/I/61WpvwdiM0L._SL1500_.jpg', '2018-11-09 15:30:45', 'Mobilite', 1, 0),
(32, ' Cozmo par Anki, un robot pour enfants et adultes pour jouer et apprendre à coder ', 199.9, 'Cozmo est un personnage aux multiples mimiques qui semble tout droit sorti d’un film. Ce petit robot étonnamment intelligent a un caractère bien trempé et sa personnalité unique évolue à votre contact. Défiez-le à des jeux ou activez le mode explorateur pour découvrir le monde à travers ses yeux. Cozmo est doté de l’atelier de programmation idéal pour donner libre cours à l’imagination des programmeurs débutants. Plus facile à utiliser et plus solide qu\'il n\'y paraît, il a été soumis à des tests rigoureux de sécurité et de durabilité Fonctionne avec un appareil compatible iOS ou Android et l\'app gratuite Cozmo.\r\n', 'Neuf', 'https://www.objetconnecte.net/wp-content/uploads/2016/12/product-hero-image-desktop.jpg', '2018-11-09 15:40:43', 'Loisirs', 1, 0),
(33, 'Lumo Dos à améliorer votre Posture ', 159, 'Qui l’eut crû, retrouver le port de tête d’un top modèle peut être amusant. L’application (iOS et Android) est à cet égard très bien faite. En gardant son smartphone à portée, l\'utilisateur éprouve une vraie satisfaction à voir son score de posture se maintenir au dessus des 95%, signe que la méthode porte ses fruits. D’autres données, tels le nombre de pas ou la quantité de sommeil, sont également mesurées en temps réel.', 'Neuf', 'https://www.ma-vie-connectee.fr/wp-content/uploads/2014/10/lumoback-ceinture.jpg', '2018-11-09 15:51:13', 'Accessoire', 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id_utilisateur` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `adresse1` varchar(50) NOT NULL,
  `adresse2` varchar(50) DEFAULT NULL,
  `cp` int(11) NOT NULL,
  `ville` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pays` varchar(30) NOT NULL,
  `date_inscription` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mdp` varchar(30) NOT NULL,
  `nombre_jeton` float NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_utilisateur`),
  UNIQUE KEY `unique_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id_utilisateur`, `nom`, `prenom`, `adresse1`, `adresse2`, `cp`, `ville`, `email`, `pays`, `date_inscription`, `mdp`, `nombre_jeton`, `type`) VALUES
(1, 'Jean', 'Jacques', '13 rue de la pénombre', ' ', 34000, 'Lattes', 'gabriel.goury@gmail.com', 'FRANCE', '2018-09-27 22:00:00', 'test', 3105, 0),
(2, 'admin', 'admin', '21 impasse des champs', 'test3', 34070, 'Montpellier', 'lucas.n@gmail.com', 'FRANCE', '2018-09-27 22:00:00', 'azerty', 0, 1),
(3, 'Friche', 'Henry', '35 rue des marques', NULL, 34000, 'Montpellier', 'fhenry@hotmail.com', 'FRANCE', '2018-09-27 22:00:00', 'henry', 3829, 0),
(4, 'azerttyy', 'admin', '21 impasse des champs', '', 34000, 'Montpellier', 'admin.test@gmail.com', 'France', '2018-10-30 18:31:24', 'test', 0, 0),
(21, 'Huret', 'Hadrien', 'Chem de Mou', 'Gauche', 34000, 'Montpellier', 'hadrienhuret1@hotmail.fr', 'FRANCE', '2018-11-01 23:23:12', 'azerty', 6176, 0);

-- --------------------------------------------------------

--
-- Structure de la table `vente`
--

DROP TABLE IF EXISTS `vente`;
CREATE TABLE IF NOT EXISTS `vente` (
  `id_vente` int(11) NOT NULL AUTO_INCREMENT,
  `id_vendeur` int(11) NOT NULL,
  `id_acheteur` int(11) NOT NULL,
  `date_vente` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nom_produit` varchar(30) NOT NULL,
  `prix` float NOT NULL,
  `libelle` varchar(30) NOT NULL,
  `etat` varchar(20) NOT NULL,
  `description` varchar(400) NOT NULL,
  `photo` varchar(500) NOT NULL,
  PRIMARY KEY (`id_vente`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `produits`
--
ALTER TABLE `produits`
  ADD CONSTRAINT `produits_utilisateurs0_FK` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateurs` (`id_utilisateur`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
