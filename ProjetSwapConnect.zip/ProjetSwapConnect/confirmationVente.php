<?php
/**
 * Created by PhpStorm.
 * User: hadri
 * Date: 02/11/2018
 * Time: 17:47
 */
include("Header.php");
include("Model.php");
$id_produit = htmlspecialchars($_GET["id"]);
$now = date("Y-m-d  H:i:s");
$infoAch = listAchete($id_produit);
$date_expiration = $infoAch['0']->date_expiration;
$id_acheteur = $infoAch['0']->id_acheteur;
$infoUserAcheteur = returnUtilisateur($id_acheteur);
$email_acheteur = $infoUserAcheteur['0']->email;
$infoProduit = returnItem($id_produit);
$nomproduit = $infoProduit['0']->nom;
if ($now < $date_expiration) {
    envoiMailAcheteurConfirm($email_acheteur, $nomproduit);
    produitVendu($id_produit);
    ?>
    <div style="text-align: center;">
        <br/><br/><br/><br/>
        <b>Vous avez accepté l'offre pour votre produit.<br/>
            Votre produit vient d'être vendu et <u>vous venez d'être payé</u> !<br/><br/>
            Vous allez être redirigé vers votre profil dans 5 secondes.</b>
    </div>
    <?php
    header("refresh:5;url=Profile.php");
} else {
    envoiMailAcheteurCancel($email_acheteur, $nomproduit);
    remiseEnVente($id_produit);
    ?>
    <div style="text-align: center;">
        <br/><br/><br/><br/>
        <b>L'offre pour votre produit a expiré.<br/>
            Votre produit vient d'être remis en vente.<br/><br/>
            Vous allez être redirigé vers votre profil dans 5 secondes.</b>
    </div>
<?php
    header("refresh:5;url=Profile.php");
}